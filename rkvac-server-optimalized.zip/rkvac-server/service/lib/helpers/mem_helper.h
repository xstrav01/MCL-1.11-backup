/**
 *
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef __RKVAC_PROTOCOL_MEM_HELPER_H_
#define __RKVAC_PROTOCOL_MEM_HELPER_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/sendfile.h>
#include <fcntl.h>
#include <unistd.h>
#include <limits.h>
#include <stdbool.h>
#include <string.h>

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>


/**
 * Check if a file with the file_name already exists.
 *
 * @param file_name string containing the name of the file to be opened.
 *
 * @return if the file is exists, the function returns true,  else false. In case of error false.
*/
extern bool is_file_exists (const char *file_name);

/**
 * Check if a file with the file_name already exists. The file is created if it does not exist.
 *
 * @param file_name string containing the name of the file to be opened.
 * @param path_to_file path to file directory. It could be '\0' or NULL.
 *
 * @return if the file is successfully opened, the function returns 0,  else -1
*/
extern int check_data_file (const char *file_name, char *path_to_file);

/**
 * Create multiple levels of directories.
 *
 * @param path string containing path to the directory
 * @param mode string containing a file access mode.
 *
 * @return if the file is successfully opened, the function returns 0,  else -1
*/
bool recursive_mkdir(char *path, mode_t mode);

/**
 * Opens the file whose name is specified in the parameter file_name and  path_to_file. Associates it with a stream
 * that can be identified in future operations by the FILE pointer returned.
 *
 * @param file_name string containing the name of the file to be opened.
 * @param path_to_file path to file directory. It could be '\0', then the function returns default path to file
 * @param mode string containing a file access mode.
 *
 * @return if the file is successfully opened, the function returns a pointer to a FILE object,  else NULL pointer
*/
extern FILE * open_data_file (const char *file_name, char *path_to_file, const char *mode);

/**
 * Copy file from source to dest
 *
 * @param source
 * @param destination
 *
 * @return
 */
extern int copy_file(const char* source, const char* destination);

#ifdef __cplusplus
}
#endif

#endif /* __RKVAC_PROTOCOL_MEM_HELPER_H_ */

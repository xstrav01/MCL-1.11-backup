/**
 *
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "mem_helper.h"

/**
 * Check if a file with the file_name already exists.
 *
 * @param file_name string containing the name of the file to be opened.
 *
 * @return if the file is exists, the function returns true,  else false. In case of error false.
*/
bool is_file_exists (const char *file_name)
{
    struct stat st;

    if (file_name == NULL)
    {
        return -1;
    }

    // check if file exist
    if(-1 == stat(file_name, &st))
    {
        if(ENOENT != errno)
        {
            /* does not exist */
            return false;
        } else return false;
    }
    else
    {
        if(S_ISDIR(st.st_mode))
        {
            /* it's a dir */
            return false;
        }
        else
        {
            /* exists but is no dir */
            return true;
        }
    }
}

#pragma clang diagnostic push
#pragma ide diagnostic ignored "misc-no-recursion"
/**
 * Create multiple levels of directories.
 *
 * @param path string containing path to the directory
 * @param mode string containing a file access mode.
 *
 * @return if the file is successfully opened, the function returns 0,  else -1
*/
bool recursive_mkdir(char *path, mode_t mode)
{
    char *sep = strrchr(path, '/');
    if(sep != NULL) {
        *sep = 0;
        recursive_mkdir(path, mode);
        *sep = '/';
    }
    if(mkdir(path, mode) && errno != EEXIST)
    {
        printf(" Error while trying to create '%s' directory!\n", path);
        return false;
    }

    return true;
}
#pragma clang diagnostic pop

/**
 * Check if a file with the file_name already exists. The file is created if it does not exist.
 *
 * @param file_name string containing the name of the file to be opened.
 * @param path_to_file path to file directory. It could be '\0' or NULL.
 *
 * @return if the file is successfully opened, the function returns 0,  else -1
*/
int check_data_file (const char *file_name, char *path_to_file)
{
    char tmp_path[PATH_MAX];
    struct stat st;

    FILE *tmp_file;

    if((strlen(tmp_path) + strlen(file_name) + 2) > PATH_MAX)
    {
        fprintf(stderr, "Error: too long \"path\" to file\n");
        return -1;
    }

    // assign path
    if (path_to_file != NULL || strlen(path_to_file) != 0)
    {
        // check if directory exist
        if(-1 == stat(path_to_file, &st))
        {
            if(ENOENT == errno)
            {
                /* does not exist */
                //mkdir(path, S_IRWXU);
                perror("stat() error");
                return -1;
            }
            else
            {
                perror("stat() error");
                return -1;
            }
        }
        else
        {
            if(S_ISDIR(st.st_mode))
            {
                /* it's a dir */
                strcpy(tmp_path, path_to_file);
                strcat(tmp_path, "/");
            }
            else
            {
                /* exists but is no dir */
                //mkdir(path, S_IRWXU);
                perror("stat() error");
                return -1;
            }
        }
    }

    // check if file exist
    strcat(tmp_path, file_name);
    if(-1 == stat(tmp_path, &st))
    {
        if(ENOENT != errno)
        {
            perror("stat() error");
            return -1;
        }

        tmp_file = fopen(tmp_path, "w");
        if (errno != 0 && errno != ENOENT)
        {
            perror("Error occurred while opening file.\n");
            return -1;
        }

        fclose(tmp_file);
    }

    return 0;
}

/**
 * Opens the file whose name is specified in the parameter file_name and  path_to_file. Associates it with a stream
 * that can be identified in future operations by the FILE pointer returned.
 *
 * @param file_name string containing the name of the file to be opened.
 * @param path_to_file path to file directory. It could be '\0', then the function returns default path to file
 * @param mode string containing a file access mode.
 *
 * @return if the file is successfully opened, the function returns a pointer to a FILE object,  else NULL pointer
*/
FILE * open_data_file (const char *file_name, char *path_to_file, const char *mode)
{
    FILE * tmp_file;
    char tmp_path[PATH_MAX];


    if ((strlen(file_name) + strlen(path_to_file) + 2) > PATH_MAX)
    {
        fprintf(stderr, "Error: too long \"path\" to file\n");
        return NULL;
    }

    strcpy(tmp_path, path_to_file);
    //strcat(tmp_path, "/");
    strcat(tmp_path, file_name);

    errno = 0;
    tmp_file = fopen(tmp_path, mode);
    if (errno != 0 && errno != ENOENT)
    {
        perror("Error occurred while opening file.\n");
        return NULL;
    }

    return tmp_file;
}

/**
 * Copy file from source to dest
 *
 * @param source
 * @param destination
 *
 * @return
 */
int copy_file(const char* source, const char* destination)
{
    int input, output;
    if ((input = open(source, O_RDONLY)) == -1)
    {
        return -1;
    }
    if ((output = creat(destination, 0660)) == -1)
    {
        close(input);
        return -1;
    }

    //sendfile will work with non-socket output (i.e. regular file) on Linux 2.6.33+
    off_t bytesCopied = 0;
    struct stat fileinfo = {0};
    fstat(input, &fileinfo);
    int result = sendfile(output, input, &bytesCopied, fileinfo.st_size);

    close(input);
    close(output);

    return result;
}
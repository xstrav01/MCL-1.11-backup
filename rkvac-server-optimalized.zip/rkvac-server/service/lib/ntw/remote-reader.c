/**
 *
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "remote-reader.h"

/**
 * Create a new socket of type IPv4 protocol in domain DOMAIN, using protocol PROTOCOL. If PROTOCOL is zero, one is chosen
 * automatically. After creation of the socket, bind function binds the socket to the local address and port number.
 * Then puts the server socket in a passive mode, where it waits for the client to approach the server to make a
 * connection.
 *
 *
 * @param ntw_type communication type - SOCK_STREAM = TCP, SOCK_DGRAM = UDP
 * @param ntw_protocol protocol value for Internet Protocol(IP), which is 0. This is the same number which appears on
 *        protocol field in the IP header of a packet.(man protocols for more details)
 * @param socket_server_id server socket identifier
 * @param server_addr server connection information
 *
 * @return 0 if success else an error code
 */
extern int ntw_ipv4_server_open_connection(int ntw_type, int ntw_protocol, int *socket_server_id, struct sockaddr_in *server_addr)
{
    int on = 1;
    int max_sd;
    int r;

    struct timeval connection_timeout, received_timeout;
    fd_set sd_set;

    // Create stream socket to receive incoming connections on
    *socket_server_id = socket(server_addr->sin_family, ntw_type, ntw_protocol);
    if (*socket_server_id == -1) {
# ifndef NDEBUG
        fprintf(stderr, "[!] Socket creation failed!\n");
# endif
        return -1;
    }

    // Allow socket descriptor to be reuseable
    r = setsockopt(*socket_server_id, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on));
    if (r < 0)
    {
# ifndef NDEBUG
        perror("setsockopt() failed");
# endif
        close(*socket_server_id);
        return -1;
    }

    // Initialize the timeval struct to SOCKET_RECEIVED_TIMEOUT in seconds.
    received_timeout.tv_sec  = SOCKET_RECEIVED_TIMEOUT;
    received_timeout.tv_usec = 0;

    // Sets the timeout value that specifies the maximum amount of time an input function waits until it completes.
    setsockopt(*socket_server_id, SOL_SOCKET, SO_RCVTIMEO, &received_timeout, sizeof(struct timeval));
    if (r < 0)
    {
# ifndef NDEBUG
        perror("setsockopt() failed");
# endif
        close(*socket_server_id);
        return -1;
    }

    /*
     * Set socket to be nonblocking. All of the sockets for the incoming connections will also be nonblocking since
     * they will inherit that state from the listening socket.
     */
    r = ioctl(*socket_server_id, FIONBIO, (char *)&on);
    if (r < 0)
    {
# ifndef NDEBUG
        perror("ioctl() failed");
# endif
        close(*socket_server_id);
        return -1;
    }

# ifndef NDEBUG
    fprintf(stdout, "[i] Socket successfully created.\n");
# endif

    // Bind the socket
    r = bind(*socket_server_id, (SA*)server_addr, sizeof(*server_addr));
    if (r < 0)
    {
# ifndef NDEBUG
        perror("bind() failed");
# endif
        close(*socket_server_id);
        return -1;
    }

# ifndef NDEBUG
    fprintf(stdout, "[i] Socket successfully binded.\n");
# endif

    // Set the listen back log
    r = (listen(*socket_server_id, 5));
    if (r != 0)
    {
# ifndef NDEBUG
        perror("listen() failed");
# endif
        close(*socket_server_id);
        return -1;
    }

    // Initialize the sd_set
    FD_ZERO(&sd_set);
    max_sd = *socket_server_id;
    FD_SET(*socket_server_id, &sd_set);

    // Initialize the timeval struct to SOCKET_LISTEN_TIMEOUT in seconds.
    connection_timeout.tv_sec  = SOCKET_LISTEN_TIMEOUT;
    connection_timeout.tv_usec = 0;

# ifndef NDEBUG
    fprintf(stdout, "[i] Server listening...\n");
# endif

    // Call select() and wait SOCKET_LISTEN_TIMEOUT for it to complete.
    r = select(max_sd + 1, &sd_set, NULL, NULL, &connection_timeout);
    if (r < 0)
    {
# ifndef NDEBUG
        perror("select() failed");
# endif
        close(*socket_server_id);
        return -1;
    }
    if (r == 0)
    {
# ifndef NDEBUG
        fprintf(stderr, "Error: select() connection_timeout!\n");
# endif
        close(*socket_server_id);
        return -1;
    }

    return 0;
}

/**
 * Accept connection
 *
 * @param socket_serv_id server socket identifier
 * @param socket_client_id client socket identifier
 * @param client_addr client connection information
 */
extern int ntw_ipv4_server_accept_connection(int socket_serv_id, int *socket_client_id, struct sockaddr_in *client_addr)
{
    int addr_length;

    // Accept the data packet from client and verification
    addr_length = sizeof(struct sockaddr_in);
    *socket_client_id = accept(socket_serv_id, (SA*)client_addr, (socklen_t*)&addr_length);
    if (*socket_client_id < 0) {
# ifndef NDEBUG
        fprintf(stderr, "Server accept failed!\n");
# endif
        return -1;
    }

# ifndef NDEBUG
    fprintf(stdout, "[i] Server accept the client %s:%d\n", inet_ntoa(client_addr->sin_addr), ntohs(client_addr->sin_port));
# endif

    return 0;
}

/**
 * Close the socket.
 *
 *
 * @param socket_id the socket identifier
 *
 * @return 0 if success else an error code
 */
extern int ntw_close_connection(int socket_id)
{
    // Close the socket
    close(socket_id);

    return 0;
}

/**
 * Sends data to the remote smart card and gets the response.
 *
 * @param socket_id socket identifier
 * @param pbSendBuffer the buffer for sending data
 * @param dwSendLength the length of the buffer for sending data
 * @param pbRecvBuffer the buffer for receiving data
 * @param dwRecvLength the length of the buffer for receiving data
 * @param elapsed_time the elapsed time if requested
 * @return 0 if success else an error code
 */
extern int32_t ntw_transmit_data(int socket_id, const uint8_t *pbSendBuffer, uint32_t dwSendLength, uint8_t *pbRecvBuffer, uint32_t *dwRecvLength, double *elapsed_time)
{
    struct timespec ts_start = {0, 0};
    struct timespec ts_end = {0, 0};

#ifndef NDEBUG
    uint32_t i;
#endif
    int32_t rv;

    // Send data to select the app
#ifndef NDEBUG
    fprintf(stdout, "[+] Remote SCard request :\n");
    for (i = 0; i < dwSendLength; i++)
    {
        fprintf(stdout, "%02X ", pbSendBuffer[i]);
    }
    fprintf(stdout, "\n");
#endif

    // Exchange APDU message
    clock_gettime(CLOCK_MONOTONIC, &ts_start);
    rv = write(socket_id, pbSendBuffer, dwSendLength);
    if (rv == -1)
    {
        return rv;
    }

    rv = read(socket_id, pbRecvBuffer, *dwRecvLength);
    if (rv == -1)
    {
#ifndef NDEBUG
        perror("read() failed");
#endif
        return rv;
    } else
        *dwRecvLength = rv;
    clock_gettime(CLOCK_MONOTONIC, &ts_end);

    rv = ntw_get_err_code(pbRecvBuffer, *dwRecvLength);
    if (rv != SCARD_S_SUCCESS)
    {
        return rv;
    }

    // calculate the elapsed time if requested
    if (elapsed_time != NULL)
    {
        *elapsed_time = ((double) ts_end.tv_sec + 1.0e-9 * (double) ts_end.tv_nsec) - ((double) ts_start.tv_sec + 1.0e-9 * (double) ts_start.tv_nsec);
    }

#ifndef NDEBUG
    fprintf(stdout, "[+] Remote SCard response:\n");
    for (i = 0; i < *dwRecvLength; i++)
    {
        fprintf(stdout, "%02X ", pbRecvBuffer[i]);
    }
    fprintf(stdout, "\n\n");
#endif

    return 0;
}

/**
 * Get response error code.
 *
 * @param pbRecvBuffer the received data
 * @param dwRecvLength the length of the received data
 * @return error code
 */
extern int32_t ntw_get_err_code(const uint8_t *pbRecvBuffer, uint32_t dwRecvLength)
{
    if (dwRecvLength < SW_LENGTH)
        return SCARD_E_INVALID_HANDLE;


    switch (pbRecvBuffer[dwRecvLength - SW_LENGTH])
    {
        case 0x90:
            switch (pbRecvBuffer[dwRecvLength - SW_LENGTH + 1])
            {
                case 0x00:
                    return SCARD_S_SUCCESS;

                default:
                    return SCARD_E_INVALID_HANDLE;
            }

        case 0x91:
            switch (pbRecvBuffer[dwRecvLength - SW_LENGTH + 1])
            {
                case 0xAF:
                    return SCARD_S_SUCCESS;

                default:
                    return SCARD_E_INVALID_HANDLE;
            }

        default:
            return SCARD_E_INVALID_HANDLE;
    }
}

/**
 * Create a new socket of type IPv4 protocol in domain DOMAIN, using protocol PROTOCOL. If PROTOCOL is zero, one is chosen
 * automatically. Connect the client socket to server socket.
 *
 *
 * @param ntw_type communication type - SOCK_STREAM = TCP, SOCK_DGRAM = UDP
 * @param ntw_protocol protocol value for Internet Protocol(IP), which is 0. This is the same number which appears on
 *        protocol field in the IP header of a packet.(man protocols for more details)
 * @param socket_client_id server socket identifier
 * @param server_addr server connection information
 *
 * @return 0 if success else an error code
 */
extern int ntw_ipv4_client_open_connection(int ntw_type, int ntw_protocol, int *socket_client_id, struct sockaddr_in *server_addr)
{
    // socket create and verification
    *socket_client_id = socket(server_addr->sin_family, ntw_type, ntw_protocol);
    if (*socket_client_id == -1) {
# ifndef NDEBUG
        fprintf(stderr, "[!] Socket creation failed!\n");
# endif
        return -1;
    }

# ifndef NDEBUG
    fprintf(stdout, "[i] Socket successfully created.\n");
# endif

    // connect the client socket to server socket
    if (connect(*socket_client_id, (SA*)server_addr, sizeof(*server_addr)) != 0) {
# ifndef NDEBUG
        fprintf(stderr, "[!] Connection to the server failed!\n");
# endif
        return -1;
    }
# ifndef NDEBUG
    fprintf(stdout, "[i] Connected to the server.\n");
# endif

    return 0;
}
/**
 *
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef __RKVAC_PROTOCOL_CONTROLLER_REMOTE_READER_H_
#define __RKVAC_PROTOCOL_CONTROLLER_REMOTE_READER_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <service/config/network-config.h>
#include "service/include/multos/apdu.h"
#include <sys/ioctl.h>

#include <PCSC/pcsclite.h>


/**
 * Create a new socket of type IPv4 protocol in domain DOMAIN, using protocol PROTOCOL. If PROTOCOL is zero, one is chosen
 * automatically. After creation of the socket, bind function binds the socket to the local address and port number.
 * Then puts the server socket in a passive mode, where it waits for the client to approach the server to make a
 * connection.
 *
 *
 * @param ntw_type communication type - SOCK_STREAM = TCP, SOCK_DGRAM = UDP
 * @param ntw_protocol protocol value for Internet Protocol(IP), which is 0. This is the same number which appears on
 *        protocol field in the IP header of a packet.(man protocols for more details)
 * @param socket_server_id server socket identifier
 * @param server_addr server connection information
 *
 * @return 0 if success else an error code
 */
extern int ntw_ipv4_server_open_connection(int ntw_type, int ntw_protocol, int *socket_server_id, struct sockaddr_in *server_addr);


/**
 * Accept connection
 *
 * @param socket_serv_id server socket identifier
 * @param socket_client_id client socket identifier
 * @param client_addr client connection information
 *
 * @return 0 if success else an error code
 */
extern int ntw_ipv4_server_accept_connection(int socket_serv_id, int *socket_client_id, struct sockaddr_in *client_addr);

/**
 * Close the socket.
 *
 *
 * @param socket_id socket identifier
 *
 * @return 0 if success else an error code
 */
extern int ntw_close_connection(int socket_id);

/**
 * Sends data to the smart card and gets the response.
 *
 * @param socket_id socket identifier
 * @param pbSendBuffer the buffer for sending data
 * @param dwSendLength the length of the buffer for sending data
 * @param pbRecvBuffer the buffer for receiving data
 * @param dwRecvLength the length of the buffer for receiving data
 * @param elapsed_time the elapsed time if requested
 * @return 0 if success else an error code
 */
extern int32_t ntw_transmit_data(int socket_id, const uint8_t *pbSendBuffer, uint32_t dwSendLength, uint8_t *pbRecvBuffer, uint32_t *dwRecvLength, double *elapsed_time);

/**
 * Get response error code.
 *
 * @param pbRecvBuffer the received data
 * @param dwRecvLength the length of the received data
 * @return error code
 */
extern int32_t ntw_get_err_code(const uint8_t *pbRecvBuffer, uint32_t dwRecvLength);

/**
 * Create a new socket of type IPv4 protocol in domain DOMAIN, using protocol PROTOCOL. If PROTOCOL is zero, one is chosen
 * automatically. Connect the client socket to server socket.
 *
 *
 * @param ntw_type communication type - SOCK_STREAM = TCP, SOCK_DGRAM = UDP
 * @param ntw_protocol protocol value for Internet Protocol(IP), which is 0. This is the same number which appears on
 *        protocol field in the IP header of a packet.(man protocols for more details)
 * @param socket_client_id server socket identifier
 * @param server_addr server connection information
 *
 * @return 0 if success else an error code
 */
extern int ntw_ipv4_client_open_connection(int ntw_type, int ntw_protocol, int *socket_client_id, struct sockaddr_in *server_addr);

#ifdef __cplusplus
}
#endif

#endif /* __RKVAC_PROTOCOL_CONTROLLER_REMOTE_READER_H_ */

/**
 *
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef __RKVAC_PROTOCOL_SERVICE_CONFIG_H
#define __RKVAC_PROTOCOL_SERVICE_CONFIG_H

#ifdef __cplusplus
extern "C"
{
#endif

#define DEFAULT_DIRECTORY_FOR_ISSUER_DATA       "./data/Issuer/"
#define DEFAULT_DIRECTORY_FOR_RA_DATA           "./data/RA/"
#define DEFAULT_DIRECTORY_FOR_VERIFIER_DATA     "./data/Verifier/"
#define IE_USER_LIST_FILENAME                   "user_list.csv"
#define IE_USER_ATTRIBUTES_FILENAME             "user_atrib.csv"
#define IE_PRIVATE_KEYS_FILENAME                "ie_sk.dat"
#define RA_PARAMETERS_FILENAME                  "ra_parameters.dat"
#define RA_PUBLIC_PARAMETERS_FILENAME           "ra_public_parameters.dat"
#define RA_PUBLIC_KEY_FILENAME                  "ra_pk.dat"
#define RA_PRIVATE_KEY_FILENAME                 "ra_sk.dat"
#define RA_REVOCATION_HANDLER_FILENAME          "ra_rh.csv"
#define RA_REVOKED_REVOCATION_HANDLER_FILENAME  "ra_rm_revoked.csv"
#define VE_EPOCH_FILENAME                       "ve_epoch.dat"
#define RA_EPOCH_FILENAME                       "ve_epoch_for_RA.dat"
#define VE_BLACKLIST_FILENAME                   "ve_BL.dat"
#define VE_LOG_FILENAME                         "ve_requests.log"

#define CREDENTIALS_DEFAULT_VALUE               "0"
#define NUMBER_OF_CREDENTIALS_TYPES             4

#define TERMINAL_COLOR_RED                      "\x1B[31m"
#define TERMINAL_COLOR_GRN                      "\x1B[32m"
#define TERMINAL_COLOR_CYN                      "\x1B[36m"
#define TERMINAL_COLOR_RESET                    "\x1B[0m"


#ifdef __cplusplus
}
#endif

#endif //__RKVAC_PROTOCOL_SERVICE_CONFIG_H

/**
 *
 *  Copyright (C) 2020  Raul Casanova Marques
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "verifier.h"

/**
* Get the user attributes from file.
*
* @param credentials the Issuer credentials
* @param ue_attributes the user attributes
* @param ve_user_attributes_file file with the user attributes. The file should be opened in mode "r".
*
* @return 0 if success else -1
*/
int ve_get_user_attributes(ie_credentials_t *credentials, user_attributes_t *ue_attributes, FILE *ve_user_attributes_file)
{
    char data[4096]= {0};
    char *pch;

    size_t it = 0;
    int r;

    if (ve_user_attributes_file == NULL )
    {
        fprintf(stderr, "Error: invalid ie_user_attributes file!\n");
        return -1;
    }

    if (ue_attributes == NULL)
    {
        fclose(ve_user_attributes_file);
        return -1;
    }

    r = read_data_from_file(ve_user_attributes_file, data, sizeof(data));
    if (r <= 0)
    {
        fprintf(stderr, "Error: invalid ie_user_attributes file!\n");
        fclose(ve_user_attributes_file);
        return -1;
    }
    else
    {
        pch = strtok(data, ";");

        while (pch != NULL)
        {
            fprintf(stdout, " [%d] %s: ", it + 1, pch);

            pch = strtok(NULL, ";");
            fprintf(stdout, "%s -> hash: ", pch);
            hex2mem((unsigned char *) credentials->ie_credentials_details.ue_attributes.ie_attributes_str_value[it].str_value, pch, EC_SIZE);

            pch = strtok(NULL, "\n");
            fprintf(stdout, "%s\n", pch);

            hex2mem(ue_attributes->attributes[it].value, pch, EC_SIZE);
            pch = strtok(NULL, ";");
            it++;
        }
        credentials->ie_credentials_details.ue_attributes.num_attributes = it;
        ue_attributes->num_attributes = it;
    }

    fclose(ve_user_attributes_file);
    return 0;
}

/**
 * Generates a nonce to be used in the proof of knowledge.
 *
 * @param nonce the nonce to be generated
 * @param nonce_length the length of the nonce
 * @return 0 if success else -1
 */
int ve_generate_nonce(void *nonce, size_t nonce_length)
{
    int r;

    if (nonce == NULL || nonce_length != NONCE_LENGTH)
    {
        return -1;
    }

    // random nonce
    r = RAND_bytes(nonce, nonce_length);
    if (r != 1)
    {
        return -1;
    }

    return 0;
}

/**
 * Generates an epoch to be used in the proof of knowledge.
 *
 * @param epoch the epoch to be generated
 * @param epoch_length the length of the epoch
 * @param epoch_file file where epoch will be stored. The file must be opened in mode "w".
 *
 * @return 0 if success else -1
 */
int ve_generate_epoch(void *epoch, size_t epoch_length, FILE *epoch_file)
{
    struct tm *tm_info;
    time_t time_info;

    uint8_t last_epoch[EPOCH_LENGTH];
    char str_epoch[2 * EPOCH_LENGTH +1];

    int r;

    if (epoch_file == NULL)
    {
        return -1;
    }

    if (epoch == NULL || epoch_length != EPOCH_LENGTH)
    {
        fclose(epoch_file);
        return -1;
    }

    // copy given epoch to temp
    memcpy(last_epoch, epoch, epoch_length);

    // current epoch
    time(&time_info);
    tm_info = localtime(&time_info);

    /* epoch in raw format
    ((uint8_t *) epoch)[0] = tm_info->tm_mday; // day of the month
    ((uint8_t *) epoch)[1] = tm_info->tm_mon; // month of the year
    ((uint8_t *) epoch)[2] = ((unsigned int) tm_info->tm_year >> 8u) & 0xFFu; // year (high byte)
    ((uint8_t *) epoch)[3] = tm_info->tm_year; // year (low byte)
    */

    strftime(&str_epoch[2], sizeof(str_epoch) - 2, "%d%m%y", tm_info);
    hex2mem(&(((uint8_t *) epoch)[1]), &str_epoch[2], epoch_length - 1);

    // initialize epoch counter
    r = memcmp(epoch, last_epoch, epoch_length);
    if (r == 0)
    {
        (((uint8_t *) epoch)[0])++;
    }
    else
    {
        (((uint8_t *) epoch)[0]) = 0x01;
    }
    mem2hex(str_epoch, epoch, epoch_length);

    // write epoch to the file
    r = write_data_to_file(epoch_file, str_epoch, strlen(str_epoch));
    if (r != strlen(str_epoch))
    {
        fclose(epoch_file);
        return -1;
    }

    fclose(epoch_file);
    return 0;
}

/**
 * Load an epoch to be used in the proof of knowledge.
 *
 * @param epoch the epoch to be generated
 * @param epoch_length the length of the epoch
 * @param epoch_file file where epoch will be stored. The file should be opened in mode "r".
 *
 * @return 0 if success else -1
 */
int ve_get_epoch(void *epoch, size_t epoch_length, FILE *epoch_file)
{
    char str_epoch[2 * EPOCH_LENGTH];

    int r;

    if (epoch_file == NULL)
    {
        return -1;
    }

    if (epoch == NULL || epoch_length != EPOCH_LENGTH)
    {
        fclose(epoch_file);
        return -1;
    }

    // read epoch from the file
# ifndef NDEBUG
    fprintf(stdout, "[+] Reading epoch from file.\n");
# endif
    r = read_data_from_file(epoch_file, str_epoch, sizeof(str_epoch));
    if (r != sizeof(str_epoch))
    {
        fprintf(stderr, "Error: invalid epoch file!\n");
        fclose(epoch_file);
        return -1;
    }

    hex2mem(epoch, str_epoch, epoch_length);

    fclose(epoch_file);
    return 0;
}

/**
 * Verifier load and set ra public parameters, ra public key, issuer private keys x(0),x(1)...x(n-1).
 *
 * @param ra_public_key revocation authority public key
 * @param ra_parameters the revocation authority parameters
 * @param ie_private_keys the issuer private keys
 * @param ue_attributes the user attributes
 * @param ra_public_key_file file with ra public key.
 * @param ra_public_parameters_file file with ra public parameters (aplhas_mul[1]...aplhas_mul[j] as h_j).
 * @param ie_private_keys_file file with issuer private keys x(0),x(1)...x(n-1).
 *
 * @return 0 if success else -1
 */
int ve_setup(revocation_authority_public_key_t *ra_public_key, revocation_authority_par_t *ra_parameters, issuer_keys_t *ie_private_keys, user_attributes_t ue_attributes,
             FILE *ra_public_key_file, FILE *ra_public_parameters_file, FILE *ie_private_keys_file)
{
    char data[4096]= {0};
    char *pch;

    int r;
    size_t it;
    size_t data_length;

    if (ra_public_key_file == NULL || ie_private_keys_file == NULL || ra_public_parameters_file == NULL)
    {
        if (ra_public_key_file != NULL)
            fclose(ra_public_key_file);
        if (ra_public_parameters_file != NULL)
            fclose(ra_public_parameters_file);
        if (ie_private_keys_file != NULL)
            fclose(ie_private_keys_file);
        return -1;
    }

    if (ra_public_key == NULL || ie_private_keys == NULL || ra_parameters == NULL)
    {
        fclose(ra_public_key_file);
        fclose(ra_public_parameters_file);
        fclose(ie_private_keys_file);
        return -1;
    }

    /// load revocation authority public key from file
    r = read_data_from_file(ra_public_key_file, data, sizeof(data));
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid ra_public_key file!\n");
        fclose(ra_public_key_file);
        fclose(ra_public_parameters_file);
        fclose(ie_private_keys_file);
        return -1;
    }
    else
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading ra_public key from file.\n");
# endif

        data_length = r;
        r = mclBnG2_setStr(&ra_public_key->pk, (const char *) data, data_length, 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ra_public_key file!\n");
            fclose(ra_public_key_file);
            fclose(ra_public_parameters_file);
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnG2_isValid(&ra_public_key->pk);
        if (r == 0)
        {
            fprintf(stderr, "Error: invalid ra_public_key file!\n");
            fclose(ra_public_key_file);
            fclose(ra_public_parameters_file);
            fclose(ie_private_keys_file);
            return -1;
        }
    }

    fclose(ra_public_key_file);

    /// revocation authority public parameters (h1 ... hj) from file
    r = read_data_from_file(ra_public_parameters_file, data, sizeof(data));
    if (r <= 0)
    {
        fprintf(stderr, "Error: invalid RA public parameters file!\n");
        fclose(ra_public_parameters_file);
        fclose(ie_private_keys_file);
        return -1;
    }
    else
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading RA public parameters from file.\n");
# endif


        pch = strtok(data, "\n");
        if (pch == NULL) {
            fprintf(stderr, "Error: invalid RA public parameters file!\n");
            fclose(ra_public_parameters_file);
            fclose(ie_private_keys_file);
            return -1;
        }

        // read h1 ... h_j
        it = 0;
        while (pch != NULL)
        {
            if (it > REVOCATION_AUTHORITY_VALUE_J)
            {
                fprintf(stderr, "Error: invalid RA public parameters file!\n");
                fclose(ra_public_parameters_file);
                fclose(ie_private_keys_file);
                return -1;
            }

            r = mclBnG1_setStr(&ra_parameters->alphas_mul[it], pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid RA public parameters file!\n");
                fclose(ra_public_parameters_file);
                fclose(ie_private_keys_file);
                return -1;
            }

            r = mclBnG1_isValid(&ra_parameters->alphas_mul[it]);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid RA public parameters file!\n");
                fclose(ra_public_parameters_file);
                fclose(ie_private_keys_file);
                return -1;
            }

            pch = strtok(NULL, "\n");
            it++;
        }
    }

    fclose(ra_public_parameters_file);

    /// load ie private key - x(0), x(1)...x(n-1), x(r) from file
    r = read_data_from_file(ie_private_keys_file, data, sizeof(data));
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid ie_private_keys file!\n");
        fclose(ie_private_keys_file);
        return -1;
    }
    else
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading ie_private keys from file.\n");
# endif
        // issuer private key - x(0)
        pch = strtok(data, "\n");
        if (pch == NULL)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnFr_setStr(&ie_private_keys->issuer_private_key.sk, (const char *) pch, strlen(pch), 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnFr_isValid(&ie_private_keys->issuer_private_key.sk);
        if (r != 1)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        // private keys - x(1)...x(n-1)
        for (it = 0; it < USER_MAX_NUM_ATTRIBUTES; it++)
        {
            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ie_private_keys file!\n");
                fclose(ie_private_keys_file);
                return -1;
            }

            r = mclBnFr_setStr(&ie_private_keys->attribute_private_keys[it].sk, (const char *) pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ie_private_keys file!\n");
                fclose(ie_private_keys_file);
                return -1;
            }

            r = mclBnFr_isValid(&ie_private_keys->attribute_private_keys[it].sk);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid ie_private_keys file!\n");
                fclose(ie_private_keys_file);
                return -1;
            }
        }

        // revocation private key - x(r)
        pch = strtok(NULL, "\n");
        if (pch == NULL)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnFr_setStr(&ie_private_keys->revocation_private_key.sk, (const char *) pch, strlen(pch), 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnFr_isValid(&ie_private_keys->revocation_private_key.sk);
        if (r != 1)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }
    }

    fclose(ie_private_keys_file);
    return 0;
}

/**
 * Set the user attributes to file.
 *
 * @param credentials issuer credentials
 * @param ue_attributes the user attributes
 * @param ue_attributes the user attributes
 *
 * @return 0 if success else -1
 */
int ve_set_user_attributes(ie_credentials_t credentials, user_attributes_t ue_attributes, FILE *ve_user_attributes_file)
{
    char data[4096];

    int r;
    size_t it;
    size_t data_length = 0;


    if (ve_user_attributes_file == NULL)
    {
        fprintf(stderr, "Error: invalid user attribute file!\n");
        return -1;
    }

    // write user attributes
    for (it = 0; it < credentials.ie_credentials_details.ue_attributes.num_attributes; it++)
    {
        strcpy(&data[data_length], credentials.ie_credentials_details.ie_credentials_name[it].name);
        data_length += strlen(credentials.ie_credentials_details.ie_credentials_name[it].name);
        strcat(data, ";");
        data_length++;
        strcpy(&data[data_length], credentials.ie_credentials_details.ue_attributes.ie_attributes_str_value[it].str_value);
        data_length += strlen(credentials.ie_credentials_details.ue_attributes.ie_attributes_str_value[it].str_value);
        strcat(data, ";");
        data_length++;
        mem2hex(&data[data_length], ue_attributes.attributes[it].value, EC_SIZE);
        data_length += 2 * EC_SIZE;
        strcat(data, "\n");
        data_length++;
    }
# ifndef NDEBUG
    fprintf(stdout, "[+] Writing the user attributes to the file.\n\n");
# endif

    if (data_length > sizeof(data))
    {
        fclose(ve_user_attributes_file);
        return -1;
    }

    r = write_data_to_file(ve_user_attributes_file, data, data_length);
    if (r != data_length)
    {
        fclose(ve_user_attributes_file);
        return -1;
    }

    fclose(ve_user_attributes_file);
    return 0;
}

/**
 * Outputs the SHA256(user attribute).
 *
 * @param credentials issuer credentials
 * @param ue_attribute_value 256bits hash of the user attribute
 *
 * @return 0 if success else -1
 */
int ve_generate_user_attribute(ie_attribute_str_value_t str_attributes, uint8_t *attribute_value)
{
    int r;

    mclBnFr fr_attribute;

    if (attribute_value == NULL)
    {
        return -1;
    }

    // set SHA256(string attribute)
    r = mclBnFr_setHashOf(&fr_attribute, str_attributes.str_value, strlen(str_attributes.str_value));
    if (r != 0)
    {
        return -1;
    }

    r = mclBnFr_isValid(&fr_attribute);
    if (r != 1)
    {
        return -1;
    }

    mcl_Fr_to_bytes(attribute_value, EC_SIZE, fr_attribute);

    return 0;
}

/**
 * Verifies the proof of knowledge of the user attributes.
 *
 * @param sys_parameters the system parameters
 * @param ra_parameters the revocation authority parameters
 * @param ra_public_key the revocation authority public key
 * @param ie_keys the issuer keys
 * @param nonce the nonce generated by the verifier
 * @param nonce_length the length of the nonce
 * @param epoch the epoch generated by the verifier
 * @param epoch_length the length of the epoch
 * @param attributes the attributes disclosed by the user
 * @param ue_credential the credential struct computed by the user
 * @param ue_pi the pi struct computed by the user
 * @param ra_revocation_list revocation list file with revoked H(C)
 *
 * @return 0 if success else -1
 */
int ve_verify_proof_of_knowledge(system_par_t sys_parameters, revocation_authority_par_t ra_parameters, revocation_authority_public_key_t ra_public_key,
                                 issuer_keys_t ie_keys, const void *nonce, size_t nonce_length, const void *epoch, size_t epoch_length,
                                 user_attributes_t attributes, user_credential_t ue_credential, user_pi_t ue_pi, FILE *ra_revocation_list)
{
    mclBnFr attribute;
    mclBnGT el, er;

    mclBnFr mul_result;
    mclBnG1 mul_result_g1;

    mclBnFr e;
    mclBnFr neg_e;

    mclBnG1 t_verify, t_revoke;
    mclBnG1 t_sig, t_sig1, t_sig2;

    mclBnFr fr_hash, fr_hash_neg; // H(epoch), -H(epoch)

    char *token;
    char data[MAX_INPUT];
    char str_pseudonym[2 * SHA256_DIGEST_LENGTH + 1];

    // used to obtain the point data independently of the platform
    char digest_platform_point[192] = {0};

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    unsigned char hash[SHA_DIGEST_PADDING + SHA_DIGEST_LENGTH] = {0};
    SHA_CTX ctx;

    size_t it;
    int r;

    if (nonce == NULL || nonce_length == 0 || epoch == NULL || epoch_length == 0)
    {
        return -1;
    }

    /// pseudonym C not in revocation list RL
    if (ra_revocation_list != NULL)
    {
        SHA256(digest_get_platform_point_data(digest_platform_point, ue_credential.pseudonym), digest_get_platform_point_size(), hash); // H(C)
        mem2hex(str_pseudonym, hash, SHA256_DIGEST_LENGTH);
        memset(hash, 0, sizeof(hash));
        while (fgets(data, sizeof(data), ra_revocation_list) != NULL)
        {
            token = strtok(data, "\n");
            if (strcmp(str_pseudonym, token) == 0)
            {
                fprintf(stderr, "Error: pseudonym is in revocation list!\n");
                fclose(ra_revocation_list);
                return -1;
            }
        }
        fclose(ra_revocation_list);
    }

    /// t values
    // t_verify
    mclBnFr_neg(&neg_e, &ue_pi.e); // neg_e = -e
    mclBnFr_mul(&mul_result, &neg_e, &ie_keys.issuer_private_key.sk); // mul_result = -e·x(0)
    mclBnG1_mul(&t_verify, &ue_credential.sigma_hat, &mul_result); // t_verify = sigma_hat·mul_result
    mclBnG1_mul(&mul_result_g1, &sys_parameters.G1, &ue_pi.s_v); // mul_result_g1 = G1·s_v
    mclBnG1_add(&t_verify, &t_verify, &mul_result_g1); // t_verify = t_verify + mul_result_g1
    mclBnFr_mul(&mul_result, &ie_keys.revocation_private_key.sk, &ue_pi.s_mr); // mul_result = x(r)·s_mr
    mclBnG1_mul(&mul_result_g1, &ue_credential.sigma_hat, &mul_result); // mul_result_g1 = sigma_hat·mul_result
    mclBnG1_add(&t_verify, &t_verify, &mul_result_g1); // t_verify = t_verify + mul_result_g1
    // product of non-disclosed attributes
    for (it = 0; it < attributes.num_attributes; it++)
    {
        if (attributes.attributes[it].disclosed == false)
        {
            mclBnFr_mul(&mul_result, &ie_keys.attribute_private_keys[it].sk, &ue_pi.s_mz[it]); // mul_result = x(it)·s_mz(it)
            mclBnG1_mul(&mul_result_g1, &ue_credential.sigma_hat, &mul_result); // mul_result_g1 = sigma_hat·mul_result
            mclBnG1_add(&t_verify, &t_verify, &mul_result_g1); // t_verify = t_verify + mul_result_g1
        }
    }
    // product of disclosed attributes
    for (it = 0; it < attributes.num_attributes; it++)
    {
        if (attributes.attributes[it].disclosed == true)
        {
            mcl_bytes_to_Fr(&attribute, attributes.attributes[it].value, EC_SIZE);
            mclBnFr_mul(&mul_result, &neg_e, &ie_keys.attribute_private_keys[it].sk); // mul_result = -e·x(it)
            mclBnFr_mul(&mul_result, &mul_result, &attribute); // mul_result = mul_result·mz
            mclBnG1_mul(&mul_result_g1, &ue_credential.sigma_hat, &mul_result); // mul_result_g1 = sigma_hat·mul_result
            mclBnG1_add(&t_verify, &t_verify, &mul_result_g1); // t_verify = t_verify + mul_result_g1
        }
    }
    mclBnG1_normalize(&t_verify, &t_verify);
    r = mclBnG1_isValid(&t_verify);
    if (r != 1)
    {
        return -1;
    }

    // H(epoch)
    SHA1(epoch, epoch_length, &hash[SHA_DIGEST_PADDING]);

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    mcl_bytes_to_Fr(&fr_hash, hash, EC_SIZE);
    r = mclBnFr_isValid(&fr_hash);
    if (r != 1)
    {
        return -1;
    }
    // -H(epoch)
    mclBnFr_neg(&fr_hash_neg, &fr_hash);

    // t_revoke
    mclBnG1_mul(&t_revoke, &ue_credential.pseudonym, &fr_hash_neg); // t_revoke = C·(-H(epoch))
    mclBnG1_add(&t_revoke, &sys_parameters.G1, &t_revoke); // t_revoke = G1 + t_revoke
    mclBnG1_mul(&t_revoke, &t_revoke, &neg_e); // t_revoke = t_revoke·(-e)
    mclBnG1_mul(&mul_result_g1, &ue_credential.pseudonym, &ue_pi.s_mr); // mul_result_g1 = C·s_mr
    mclBnG1_add(&t_revoke, &t_revoke, &mul_result_g1); // t_revoke = t_revoke + mul_result_g1
    mclBnG1_mul(&mul_result_g1, &ue_credential.pseudonym, &ue_pi.s_i); // mul_result_g1 = C·s_i
    mclBnG1_add(&t_revoke, &t_revoke, &mul_result_g1); // t_revoke = t_revoke + mul_result_g1
    mclBnG1_normalize(&t_revoke, &t_revoke);
    r = mclBnG1_isValid(&t_revoke);
    if (r != 1)
    {
        return -1;
    }

    // t_sig
    mclBnG1_mul(&t_sig, &sys_parameters.G1, &ue_pi.s_i); // t_sig = G1·s_i
    mclBnG1_mul(&mul_result_g1, &ra_parameters.alphas_mul[0], &ue_pi.s_e1); // mul_result_g1 = h1·s_e1
    mclBnG1_add(&t_sig, &t_sig, &mul_result_g1); // t_sig = t_sig + mul_result_g1 (G1·s_i + h1·s_e1)
    mclBnG1_mul(&mul_result_g1, &ra_parameters.alphas_mul[1], &ue_pi.s_e2); // mul_result_g1 = h2·s_e2
    mclBnG1_add(&t_sig, &t_sig, &mul_result_g1); // t_sig = t_sig + mul_result_g1 (G1·s_i + h1·s_e1 + h2·s_e2)
    mclBnG1_normalize(&t_sig, &t_sig);
    r = mclBnG1_isValid(&t_sig);
    if (r != 1)
    {
        return -1;
    }

    // t_sig1
    mclBnG1_mul(&t_sig1, &ue_credential.sigma_minus_e1, &neg_e); // t_sig1 = sigma_minus_e1·(-e)
    mclBnG1_mul(&mul_result_g1, &ue_credential.sigma_hat_e1, &ue_pi.s_e1); // mul_result_g1 = sigma_hat_e1·s_e1
    mclBnG1_add(&t_sig1, &t_sig1, &mul_result_g1); // t_sig2 = t_sig2 + mul_result_g1
    mclBnG1_mul(&mul_result_g1, &sys_parameters.G1, &ue_pi.s_v); // mul_result_g1 = G1·s_v
    mclBnG1_add(&t_sig1, &t_sig1, &mul_result_g1); // t_sig2 = t_sig2 + mul_result_g1
    mclBnG1_normalize(&t_sig1, &t_sig1);
    r = mclBnG1_isValid(&t_sig1);
    if (r != 1)
    {
        return -1;
    }

    // t_sig2
    mclBnG1_mul(&t_sig2, &ue_credential.sigma_minus_e2, &neg_e); // t_sig2 = sigma_minus_e2·(-e)
    mclBnG1_mul(&mul_result_g1, &ue_credential.sigma_hat_e2, &ue_pi.s_e2); // mul_result_g1 = sigma_hat_e2·s_e2
    mclBnG1_add(&t_sig2, &t_sig2, &mul_result_g1); // t_sig2 = t_sig2 + mul_result_g1
    mclBnG1_mul(&mul_result_g1, &sys_parameters.G1, &ue_pi.s_v); // mul_result_g1 = G1·s_v
    mclBnG1_add(&t_sig2, &t_sig2, &mul_result_g1); // t_sig2 = t_sig2 + mul_result_g1
    mclBnG1_normalize(&t_sig2, &t_sig2);
    r = mclBnG1_isValid(&t_sig2);
    if (r != 1)
    {
        return -1;
    }

#ifndef NDEBUG
    mcl_display_G1("t_verify", t_verify);
    mcl_display_G1("t_revoke", t_revoke);
    mcl_display_G1("t_sig", t_sig);
    mcl_display_G1("t_sig1", t_sig1);
    mcl_display_G1("t_sig2", t_sig2);
    mcl_display_G1("sigma_hat", ue_credential.sigma_hat);
    mcl_display_G1("sigma_hat_e1", ue_credential.sigma_hat_e1);
    mcl_display_G1("sigma_hat_e2", ue_credential.sigma_hat_e2);
    mcl_display_G1("sigma_minus_e1", ue_credential.sigma_minus_e1);
    mcl_display_G1("sigma_minus_e2", ue_credential.sigma_minus_e2);
    mcl_display_G1("pseudonym", ue_credential.pseudonym);
#endif

    /// e <-- H(...)
    SHA1_Init(&ctx);
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, t_verify), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, t_revoke), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, t_sig), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, t_sig1), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, t_sig2), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, ue_credential.sigma_hat), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, ue_credential.sigma_hat_e1), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, ue_credential.sigma_hat_e2), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, ue_credential.sigma_minus_e1), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, ue_credential.sigma_minus_e2), digest_get_platform_point_size());
    SHA1_Update(&ctx, digest_get_platform_point_data(digest_platform_point, ue_credential.pseudonym), digest_get_platform_point_size());
    SHA1_Update(&ctx, nonce, nonce_length);
    SHA1_Final(&hash[SHA_DIGEST_PADDING], &ctx);

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    mcl_bytes_to_Fr(&e, hash, EC_SIZE);
    r = mclBnFr_isValid(&e);
    if (r != 1)
    {
        return -1;
    }

#ifndef NDEBUG
    mcl_display_Fr("e", e);
#endif

    r = mclBnFr_isEqual(&ue_pi.e, &e);
    if (r != 1)
    {
        return -1;
    }

    /// pairing
    // e(sigma_minus_e1, G2)
    mclBn_pairing(&el, &ue_credential.sigma_minus_e1, &sys_parameters.G2);
    // e(sigma_hat_e1, G2)
    mclBn_pairing(&er, &ue_credential.sigma_hat_e1, &ra_public_key.pk);
    // e(sigma_minus_e1, G2) ?= e(sigma_hat_e1, G2)
    r = mclBnGT_isEqual(&el, &er);
    if (r != 1)
    {
        return -1;
    }

    // e(sigma_minus_e2, G2)
    mclBn_pairing(&el, &ue_credential.sigma_minus_e2, &sys_parameters.G2);
    // e(sigma_hat_e2, G2)
    mclBn_pairing(&er, &ue_credential.sigma_hat_e2, &ra_public_key.pk);
    // e(sigma_minus_e2, G2) ?= e(sigma_hat_e2, G2)
    r = mclBnGT_isEqual(&el, &er);
    if (r != 1)
    {
        return -1;
    }

    return 0;
}

/**
 * Update Verifier blacklist.
 *
 * @param ra_blacklist_epoch_file pointer to RA blacklist for verifier.
 * @param ve_blacklist_file pointer to Verifier blacklist.
 *
 * @return 0 if success else -1
 */
int ve_update_blacklist(FILE *ra_blacklist_epoch_file, FILE *ve_blacklist_file)
{
    int ch;

    if (ra_blacklist_epoch_file == NULL || ve_blacklist_file == NULL)
    {
        if (ra_blacklist_epoch_file != NULL)
            fclose(ra_blacklist_epoch_file);
        if (ve_blacklist_file != NULL)
            fclose(ve_blacklist_file);
        return -1;
    }

    while ((ch = fgetc(ra_blacklist_epoch_file)) != EOF)
        fputc(ch, ve_blacklist_file);

    fclose(ra_blacklist_epoch_file);
    fclose(ve_blacklist_file);

    return 0;
}

/**
 * Log proof of knowledge requests.
 *
 * @param epoch the epoch generated by the verifier
 * @param epoch_length the length of the epoch
 * @param pseudonym the user pseudonym
 * @param status status of the proof of knowledge (verified or reject)
 * @param ve_log_file file with log. The file must be opened in mode "a+".
 *
 * @return 0 if success else -1
 */
int ve_log_requests(const void *epoch, size_t epoch_length, mclBnG1 pseudonym, bool status, FILE *ve_log_file)
{
    time_t t;
    struct tm *tm;

    char data[4096];
    char s[64];

    size_t data_length;
    int r;

    // used to obtain the point data independently of the platform
    char digest_platform_point[192] = {0};

    unsigned char hash[SHA256_DIGEST_LENGTH] = {0};
    SHA256_CTX ctx;

    // date time
    t = time(NULL);
    tm = localtime(&t);
    strftime(s, sizeof(s), "%c", tm);

    strcpy(data, s);
    strcat(data, " ");
    data_length = strlen(data);

    // epoch
    mem2hex(&data[data_length], epoch, epoch_length);
    data_length += 2 * epoch_length;
    strcat(data, " ");
    data_length++;

    // H(pseudonym)
    SHA256_Init(&ctx);
    SHA256_Update(&ctx, digest_get_platform_point_data(digest_platform_point, pseudonym), digest_get_platform_point_size());
    SHA256_Final(hash, &ctx);

    mem2hex(&data[data_length], hash, sizeof(hash));
    data_length += 2 * SHA256_DIGEST_LENGTH;
    strcat(data, " ");
    data_length++;

    if (status)
    {
        strcat(data, "ACCESS ALLOWED");
        data_length += strlen("ACCESS ALLOWED");
    }
    else
    {
        strcat(data, "ACCESS DENIED");
        data_length += strlen("ACCESS DENIED");
    }

    strcat(data, "\n");
    data_length++;

    /*
     * Log file structure
     *
     * +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
     *  day of the week | month | day | time | year | epoch | SHA256(pseudonym) | status
     * +---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+---+
     */
    r = write_data_to_file(ve_log_file, data, data_length);
    if (r != data_length)
    {
        fclose(ve_log_file);
        return -1;
    }

    fclose(ve_log_file);
    return 0;
}

/**
 *
 *  Copyright (C) 2020 Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */


#include "file_helper.h"

/**
* Load last line from file.
*
* @param filestream Pointer to a FILE object that identifies an input stream.
* @param last_line_string Pointer to an array of chars where the string read is copied.
*
* @return On success, the function returns 0. In case of error, the function returns -1. If the file is empty,
* the function returns 1.
*/
int load_last_line (FILE *file_stream, char last_line_string[MAX_INPUT])
{

    int char_num;

    // check if is file empty
    char_num = fgetc(file_stream);
    if (char_num == EOF) {
        return 1; // file is empty
    }

    //find the last line position
    if (fseek(file_stream, 0L, SEEK_END) != 0)
    {
        perror( "Fseek failed" );
        return -1;
    }


    while((char_num != 10))
    {
        if (fseek(file_stream, -2L, SEEK_CUR) != 0)
        {
            if (fseek(file_stream, -1L, SEEK_CUR) != 0)
            {
                perror( "Fseek failed" );
                return -1;
            }
            break;
        }
        char_num = fgetc(file_stream);
    }

    // load last line
    fgets(last_line_string, MAX_INPUT,file_stream);

    return 0;
}

/**
* Searches for the first occurrence of the text in the column of the file pointed to
* by the argument file_stream.
*
* @param filestream Pointer to a FILE object that identifies an input stream.
* @param text Pointer to the string.
* @param column_no Column number (1 - n).
*
* @return On success, the function returns 0. In case of error, the function returns -1. If the text was not found,
* the function returns 1.
*/
int search_text_in_column (FILE *file_stream, char *text, size_t column_no)
{
    char line_string[MAX_INPUT];
    char *pch;
    int n;

    size_t it;

    // rewind to the beginning of the file
    rewind(file_stream);

    while (fgets(line_string, MAX_INPUT,file_stream) != NULL)
    {
        pch = strtok(line_string, ";");
        it = 1;

        while ((pch != NULL))
        {
            if (it == column_no)
            {
                if (pch[strlen(pch)-1] == '\n')
                    pch[strlen(pch)-1] = '\0';
                n = strcmp(text, pch);
                if (n == 0)
                    return 0;
                break;
            }
            else if (column_no == 0)
            {
                if (pch[strlen(pch)-1] == '\n')
                    pch[strlen(pch)-1] = '\0';
                n = strcmp(text, pch);
                if (n == 0)
                    return 0;
            }
            pch = strtok (NULL, ";");
            it++;
        }
    }
    return 1;
}

/**
* Searches for the first occurrence of the text of the file pointed to by the argument file_stream.
*
* @param filestream Pointer to a FILE object that identifies an input stream.
* @param text Pointer to the string.
* @param value_to_return
* @param column_no Column number (1 - n) where if value located
*
* @return On success, the function returns 0. In case of error, the function returns -1. If the text was not found,
* the function returns 1.
*/
int vertical_lookup (FILE *file_stream, char *search_text, char *value_to_return, size_t column_no)
{
    char line_string[MAX_INPUT];
    char tmp_line_string[MAX_INPUT];
    char *pch;
    int n;

    size_t it;

    // rewind to the beginning of the file
    rewind(file_stream);

    while (fgets(line_string, MAX_INPUT,file_stream) != NULL)
    {
        strcpy(tmp_line_string, line_string);
        pch = strtok(line_string, ";");
        it = 1;

        while ((pch != NULL))
        {
            if (pch[strlen(pch)-1] == '\n')
                pch[strlen(pch)-1] = '\0';
            n = strcmp(search_text, pch);
            if (n == 0)
            {
                pch = strtok(tmp_line_string, ";");
                while (pch != NULL)
                {
                    if (it == column_no)
                    {
                        if (pch[strlen(pch) - 1] == '\n')
                            pch[strlen(pch) - 1] = '\0';
                        strcpy(value_to_return, pch);
                        return 0;
                    }
                    pch = strtok (NULL, ";");
                    it++;
                }
                return -1;
            }
            pch = strtok (NULL, ";");
        }
    }
    return 1;
}

/**
* Searches for the first occurrence of the text in the file pointed to by the argument file_stream
*
* @param s1 pointer to the destination array where the line content is to be copied
* @param s2 pointer to the source of data to be searched
* @param n maximum number of bytes to return
* @param filestream Pointer to a FILE object that identifies an input stream.
*
* @return On success, the function returns 0. In case of error, the function returns -1. If the text was not found,
* the function returns 1.
*/
int get_line_text (char *s1, char *s2, size_t n, FILE *file_stream)
{
    char line_string[LINE_MAX];

    while (fgets(line_string, sizeof(line_string), file_stream) != NULL)
    {
        if (strstr(line_string, s2) != NULL)
        {
            if (strlen(line_string) > n)
                return -1;
            strcpy(s1, line_string);
            return 0;
        }
    }
    return 1;
}

/**
* Read data from file
*
* @param filestream Pointer to a FILE object that identifies an input stream.
* @param data Pointer data byte array where data will be stored.
* @param data_length The length of data array.
*
* @return On success, the total number of elements successfully read are returned. In case of error, the function returns -1.
*/
int read_data_from_file(FILE *file_stream, char *data, size_t data_length)
{
    size_t read_size;

    read_size = fread(data, sizeof(unsigned char), data_length, file_stream);

    if (read_size < 0)
    {
        return -1;
    }

    return read_size;
}

/**
* Write data to file
*
* @param filestream Pointer to a FILE object that identifies an input stream
* @param data Pointer data byte array
* @param data_length The length of data array
*
* @return On success, the total number of elements successfully written is returned. In case of error, the function returns -1.
*/
int write_data_to_file(FILE *file_stream, char *data, size_t data_length)
{
    size_t write_size;

    write_size = fwrite(data, sizeof(unsigned char), data_length, file_stream);

    if (write_size < data_length)
    {
        return -1;
    }

    return write_size;
}

/**
 * Check if a directory with the dir_name already exists.
 *
 * @param dir_name string containing the name of the directory.
 *
 * @return if the directory is exists, the function returns true,  else false. In case of error false.
*/
bool is_dir_exists (const char *dir_name) {
    struct stat st;

    // check if directory exist
    if (-1 == stat(dir_name, &st)) {
        if (ENOENT == errno) {
            /* does not exist */
            return false;
        } else {
            perror("stat() error");
            return false;
        }
    }
    else
    {
        if (S_ISDIR(st.st_mode)) {
            /* it's a dir */
            return true;
        } else {
            /* exists but is no dir */
            return false;
        }
    }
}

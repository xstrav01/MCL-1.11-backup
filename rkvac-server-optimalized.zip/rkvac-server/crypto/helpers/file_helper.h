/**
 *
 *  Copyright (C) 2020 Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef __RKVAC_PROTOCOL_FILE_HELPER_H_
#define __RKVAC_PROTOCOL_FILE_HELPER_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <sys/types.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <limits.h>

#include <string.h>

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include "hex_helper.h"

/**
* Load last line from file.
*
* @param filestream Pointer to a FILE object that identifies an input stream.
* @param last_line_string Pointer to an array of chars where the string read is copied.
*
* @return On success, the function returns 0. In case of error, the function returns -1. If the file is empty,
* the function returns 1.
*/
extern int load_last_line (FILE *file_stream, char last_line_string[MAX_INPUT]);

/**
* Searches for the first occurrence of the text in the column of the file pointed to,
* by the argument file_stream.
*
* @param filestream Pointer to a FILE object that identifies an input stream.
* @param text Pointer to the string.
* @param column_no Column number (1 - n).
*
* @return On success, the function returns 0. In case of error, the function returns -1. If the text was not found,
* the function returns 1.
*/
extern int search_text_in_column (FILE *file_stream, char *text, size_t column_no);

/**
* Searches for the first occurrence of the text of the file pointed to by the argument file_stream.
*
* @param filestream Pointer to a FILE object that identifies an input stream.
* @param text Pointer to the string.
* @param value_to_return
* @param column_no Column number (1 - n).
*
* @return On success, the function returns 0. In case of error, the function returns -1. If the text was not found,
* the function returns 1.
*/
extern int vertical_lookup (FILE *file_stream, char *search_text, char *value_to_return, size_t column_no);

/**
* Searches for the first occurrence of the text in the file pointed to by the argument file_stream
*
* @param s1 pointer to the destination array where the line content is to be copied
* @param s2 pointer to the source of data to be searched
* @param n maximum number of bytes to return
* @param filestream Pointer to a FILE object that identifies an input stream.
*
* @return On success, the function returns 0. In case of error, the function returns -1. If the text was not found,
* the function returns 1.
*/
extern int get_line_text (char *s1, char *s2, size_t n, FILE *file_stream);

/**
* Read data from file
*
* @param filestream Pointer to a FILE object that identifies an input stream.
* @param data Pointer data byte array where data will be stored.
* @param data_length The length of data array.
*
* @return On success, the total number of elements successfully read are returned. In case of error, the function returns -1.
*/
int read_data_from_file(FILE *file_stream, char *data, size_t data_length);

/**
* Write data to file
*
* @param filestream Pointer to a FILE object that identifies an input stream
* @param data Pointer data byte array
* @param data_length The length of data array
*
* @return On success, the total number of elements successfully written is returned. In case of error, the function returns -1.
*/
int write_data_to_file(FILE *file_stream, char *data, size_t data_length);

/**
 * Check if a directory with the dir_name already exists.
 *
 * @param dir_name string containing the name of the directory.
 *
 * @return if the directory is exists, the function returns true,  else false. In case of error false.
*/
bool is_dir_exists (const char *dir_name);

#ifdef __cplusplus
}
#endif

#endif /* __RKVAC_PROTOCOL_FILE_HELPER_H_ */

/**
 *
 *  Copyright (C) 2021  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "user.h"

/**
 * Sets the user identifier using the remote reader.
 *
 * @param socket_id the socket identifier
 * @param identifier the user identifier
 * @return 0 if success else -1
 */
int ue_remote_set_user_identifier(int socket_id, user_identifier_t *identifier)
{
    uint8_t pbSendBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint8_t pbRecvBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint32_t dwSendLength;
    uint32_t dwRecvLength;
    uint16_t sw1sw2 = {0};

    int r;

    if (identifier == NULL)
    {
        return -1;
    }

    dwSendLength = sizeof(pbSendBuffer);
    r = apdu_build_command(CASE3, CLA_APPLICATION, INS_SET_USER_IDENTIFIER, 0x00, 0x00, USER_MAX_ID_LENGTH, identifier->buffer, 0, pbSendBuffer, &dwSendLength);
    if (r < 0)
    {
        return -1;
    }

    dwRecvLength = sizeof(pbRecvBuffer);
    r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, NULL);
    if (r < 0)
    {
        fprintf(stderr, "Error: %s\n", sc_get_error(r));
        return r;
    }

    // get sw response
    apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
    if (r < 0)
    {
        return -1;
    }

    if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR)
    {
        fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
        return -1;
    }

    return 0;
}

/**
 * Gets the user identifier using the remote reader.
 *
 * @param socket_id the socket identifier
 * @param identifier the user identifier
 * @return 0 if success else -1
 */
int ue_remote_get_user_identifier(int socket_id, user_identifier_t *identifier)
{
    uint8_t pbSendBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint8_t pbRecvBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint32_t dwSendLength;
    uint32_t dwRecvLength;
    uint16_t sw1sw2 = {0};

    int r;

    if (identifier == NULL)
    {
        return -1;
    }

    dwSendLength = sizeof(pbSendBuffer);
    r = apdu_build_command(CASE2, CLA_APPLICATION, INS_GET_USER_IDENTIFIER, 0x00, 0x00, 0, NULL, USER_MAX_ID_LENGTH, pbSendBuffer, &dwSendLength);
    if (r < 0)
    {
        return -1;
    }

    dwRecvLength = sizeof(pbRecvBuffer);
    r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, NULL);
    if (r < 0)
    {
        fprintf(stderr, "Error: %s\n", sc_get_error(r));
        return r;
    }

    // get sw response
    apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
    if (r < 0)
    {
        return -1;
    }

    if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR)
    {
        fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
        return -1;
    }

    memcpy(identifier->buffer, pbRecvBuffer, USER_MAX_ID_LENGTH);
    identifier->buffer_length = USER_MAX_ID_LENGTH;

    return 0;
}

/**
 * Sets the revocation authority parameters and the revocation attributes.
 *
 * @param socket_id the socket identifier
 * @param ra_parameters the revocation authority parameters
 * @param ra_signature the signature of the user identifier
 * @return 0 if success else -1
 */
int ue_remote_set_revocation_authority_data(int socket_id, revocation_authority_par_t ra_parameters, revocation_authority_signature_t ra_signature)
{
    uint8_t pbSendBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint8_t pbRecvBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint32_t dwSendLength;
    uint32_t dwRecvLength;
    uint16_t sw1sw2 = {0};

    uint8_t data[2048] = {0};
    size_t data_length;

    size_t transmissions;
    size_t offset;
    size_t lc;

    size_t it;
    int r;

    data_length = 0;

    // ra_signature.mr
    mcl_Fr_to_multos_Fr(&data[data_length], sizeof(elliptic_curve_fr_t), ra_signature.mr);
    data_length += sizeof(elliptic_curve_fr_t);

    // ra_signature.sigma
    mcl_G1_to_multos_G1(&data[data_length], sizeof(elliptic_curve_point_t), ra_signature.sigma);
    data_length += sizeof(elliptic_curve_point_t);

    // k, j
    data[data_length++] = ra_parameters.k;
    data[data_length++] = ra_parameters.j;

    // alphas
    for (it = 0; it < REVOCATION_AUTHORITY_VALUE_J; it++)
    {
        mcl_Fr_to_multos_Fr(&data[data_length], sizeof(elliptic_curve_fr_t), ra_parameters.alphas[it]);
        data_length += sizeof(elliptic_curve_fr_t);
    }

    // alphas_mul
    for (it = 0; it < REVOCATION_AUTHORITY_VALUE_J; it++)
    {
        mcl_G1_to_multos_G1(&data[data_length], sizeof(elliptic_curve_point_t), ra_parameters.alphas_mul[it]);
        data_length += sizeof(elliptic_curve_point_t);
    }

    // randomizers
    for (it = 0; it < REVOCATION_AUTHORITY_VALUE_K; it++)
    {
        mcl_Fr_to_multos_Multiplier(&data[data_length], sizeof(elliptic_curve_multiplier_t), ra_parameters.randomizers[it]);
        data_length += sizeof(elliptic_curve_multiplier_t);
    }

    // randomizers_sigma
    for (it = 0; it < REVOCATION_AUTHORITY_VALUE_K; it++)
    {
        mcl_G1_to_multos_G1(&data[data_length], sizeof(elliptic_curve_point_t), ra_parameters.randomizers_sigma[it]);
        data_length += sizeof(elliptic_curve_point_t);
    }

    // calculate how many data transmissions are necessary
    transmissions = data_length / MAX_APDU_SEND_SIZE_T0 + (data_length % MAX_APDU_SEND_SIZE_T0 > 0 ? 1 : 0);

    offset = 0;
    lc = sizeof(elliptic_curve_fr_t) + sizeof(elliptic_curve_point_t); // send revocation authority data (mr, sigma) at the beginning
    for (it = 0; it < transmissions; it++)
    {
        dwSendLength = sizeof(pbSendBuffer);
        r = apdu_build_command(CASE3, CLA_APPLICATION, INS_SET_REVOCATION_AUTHORITY_DATA, it + 1, transmissions, lc, &data[offset], 0, pbSendBuffer, &dwSendLength);
        if (r < 0)
        {
            return -1;
        }

        dwRecvLength = sizeof(pbRecvBuffer);
        r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, NULL);
        if (r < 0)
        {
            fprintf(stderr, "Error: %s\n", sc_get_error(r));
            return r;
        }

        // get sw response
        apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
        if (r < 0)
        {
            return -1;
        }

        if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR && sw1sw2 != (uint16_t) CUSTOM_SW_EXPECTED_ADDITIONAL_DATA)
        {
            fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
            return -1;
        }

        offset += lc;
        lc = (offset + MAX_APDU_SEND_SIZE_T0 < data_length ? MAX_APDU_SEND_SIZE_T0 : data_length - offset);
    }

    return 0;
}

/**
 * Gets the user attributes and identifier using the remote reader.
 *
 * @param socket_id the socket identifier
 * @param attributes the user attributes
 * @param identifier the user identifier
 * @param ra_signature the signature of the user identifier
 * @return 0 if success else -1
 */
int ue_remote_get_user_attributes_identifier(int socket_id, user_attributes_t *attributes, user_identifier_t *identifier, revocation_authority_signature_t *ra_signature)
{
    uint8_t pbSendBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint8_t pbRecvBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint32_t dwSendLength;
    uint32_t dwRecvLength;
    uint16_t sw1sw2 = {0};

    uint8_t data[2048] = {0};
    size_t data_length;

    size_t transmissions;
    size_t offset;
    size_t le;

    size_t it;

    int r;

    if (/*attributes == NULL ||*/ identifier == NULL || ra_signature == NULL)
    {
        return -1;
    }

    data_length = 0;

    // calculate how many data transmissions are necessary (1 at the beginning)
    transmissions = 1;

    offset = 0;
    le = USER_MAX_ID_LENGTH + sizeof(elliptic_curve_fr_t) + sizeof(elliptic_curve_point_t) + 1; // user_identifier + revocation_authority_signature + num_attributes
    for (it = 0; it < transmissions; it++)
    {
        dwSendLength = sizeof(pbSendBuffer);
        r = apdu_build_command(CASE2, CLA_APPLICATION, INS_GET_USER_IDENTIFIER_ATTRIBUTES, it + 1, transmissions, 0, NULL, le, pbSendBuffer, &dwSendLength);
        if (r < 0)
        {
            return -1;
        }

        dwRecvLength = sizeof(pbRecvBuffer);
        r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, NULL);
        if (r < 0)
        {
            fprintf(stderr, "Error: %s\n", sc_get_error(r));
            return r;
        }

        // get sw response
        apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
        if (r < 0)
        {
            return -1;
        }

        if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR && sw1sw2 != (uint16_t) CUSTOM_SW_EXPECTED_ADDITIONAL_DATA)
        {
            fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
            return -1;
        }

        // expected length
        //assert(dwRecvLength == le + 2);
        if (dwRecvLength != le + 2)
        {
            fprintf(stderr, "Error: wrong APDU response!\n");
            return -1;
        }

        // copy received data
        memcpy((void *) &data[offset], (const void *) pbRecvBuffer, dwRecvLength - 2);

        /*
         * This part get user attributes from smart card
         *
        // calculates how many transmissions are needed
        if (it == 0)
        {
            attributes->num_attributes = pbRecvBuffer[dwRecvLength - 3];
            data_length = attributes->num_attributes * sizeof(elliptic_curve_fr_t);
            transmissions += data_length / MAX_APDU_SEND_SIZE_T0 + (data_length % MAX_APDU_SEND_SIZE_T0 > 0 ? 1 : 0);
            data_length += le; // fix data length by adding the data already sent
        }

        offset += le;
        data_length -= le; // subtract the amount of data to be received
        le = (data_length > MAX_APDU_SEND_SIZE_T0 ? MAX_APDU_SEND_SIZE_T0 : data_length);
        */
    }

    data_length = 0;

    // user_identifier
    memcpy(identifier->buffer, &data[data_length], USER_MAX_ID_LENGTH);
    identifier->buffer_length = USER_MAX_ID_LENGTH;
    data_length += USER_MAX_ID_LENGTH;

    // ra_signature.mr
    multos_Fr_to_mcl_Fr(&ra_signature->mr, &data[data_length], sizeof(elliptic_curve_fr_t));
    r = mclBnFr_isValid(&ra_signature->mr);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_fr_t);

    // ra_signature.sigma
    multos_G1_to_mcl_G1(&ra_signature->sigma, &data[data_length], sizeof(elliptic_curve_point_t));
    r = mclBnG1_isValid(&ra_signature->sigma);
    if (r != 1)
    {
        return -1;
    }

    /*
     * This part assign user attributes from smart card to the variables
     *
    data_length += sizeof(elliptic_curve_point_t);

    // num_attributes
    attributes->num_attributes = data[data_length];
    data_length += 1;

    // attributes
    for (it = 0; it < attributes->num_attributes; it++)
    {
        memcpy(attributes->attributes[it].value, &data[data_length], sizeof(elliptic_curve_fr_t));
        data_length += sizeof(elliptic_curve_fr_t);
    }
    */

    return 0;
}

/**
 * Sets the user attributes using the remote reader.
 *
 * @param socket_id the socket identifier
 * @param attributes the user attributes
 * @return 0 if success else -1
 */
int ue_remote_set_user_attributes(int socket_id, user_attributes_t ue_attributes)
{
    uint8_t pbSendBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint8_t pbRecvBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint32_t dwSendLength;
    uint32_t dwRecvLength;
    uint16_t sw1sw2 = {0};

    uint8_t data[2048] = {0};
    size_t data_length;

    size_t transmissions;
    size_t offset;
    size_t lc;

    size_t it;
    int r;

    data_length = 0;

    // copy number of attributes
    data[data_length++] = ue_attributes.num_attributes;
    // copy attributes
    for (it = 0; it < ue_attributes.num_attributes; it++)
    {
        memcpy(&data[data_length], &ue_attributes.attributes[it].value, sizeof(elliptic_curve_fr_t));
        data_length += sizeof(elliptic_curve_fr_t);
    }

    // calculate how many data transmissions are necessary
    transmissions = data_length / MAX_APDU_SEND_SIZE_T0 + (data_length % MAX_APDU_SEND_SIZE_T0 > 0 ? 1 : 0);

    offset = 0;
    lc = (MAX_APDU_SEND_SIZE_T0 < data_length ? MAX_APDU_SEND_SIZE_T0 : data_length);
    for (it = 0; it < transmissions; it++)
    {
        dwSendLength = sizeof(pbSendBuffer);
        r = apdu_build_command(CASE3, CLA_APPLICATION, INS_SET_USER_ATTRIBUTES, it + 1, transmissions, lc, &data[offset], 0, pbSendBuffer, &dwSendLength);
        if (r < 0)
        {
            return -1;
        }

        dwRecvLength = sizeof(pbRecvBuffer);
        r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, NULL);
        if (r < 0)
        {
            fprintf(stderr, "Error: %s\n", sc_get_error(r));
            return r;
        }

        // get sw response
        apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
        if (r < 0)
        {
            return -1;
        }

        if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR && sw1sw2 != (uint16_t) CUSTOM_SW_EXPECTED_ADDITIONAL_DATA)
        {
            fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
            return -1;
        }

        offset += lc;
        lc = (offset + MAX_APDU_SEND_SIZE_T0 < data_length ? MAX_APDU_SEND_SIZE_T0 : data_length - offset);
    }

    return 0;
}

/**
 * Sets the issuer signatures of the user's attributes using the remote reader.
 *
 * @param socket_id the socket identifier
 * @param ie_parameters the issuer parameters
 * @param ie_signature the issuer signature
 * @return 0 if success else -1
 */
int ue_remote_set_issuer_signatures(int socket_id, issuer_par_t ie_parameters, issuer_signature_t ie_signature)
{
    uint8_t pbSendBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint8_t pbRecvBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint32_t dwSendLength;
    uint32_t dwRecvLength;
    uint16_t sw1sw2 = {0};

    uint8_t data[2048] = {0};
    size_t data_length;

    size_t transmissions;
    size_t offset;
    size_t lc;

    size_t it;
    int r;

    data_length = 0;

    // ie_signature.sigma
    mcl_G1_to_multos_G1(&data[data_length], sizeof(elliptic_curve_point_t), ie_signature.sigma);
    data_length += sizeof(elliptic_curve_point_t);

    // ie_signature.revocation_sigma
    mcl_G1_to_multos_G1(&data[data_length], sizeof(elliptic_curve_point_t), ie_signature.revocation_sigma);
    data_length += sizeof(elliptic_curve_point_t);

    // ie_signature.attribute_sigmas
    for (it = 0; it < ie_parameters.num_attributes; it++)
    {
        mcl_G1_to_multos_G1(&data[data_length], sizeof(elliptic_curve_point_t), ie_signature.attribute_sigmas[it]);
        data_length += sizeof(elliptic_curve_point_t);
    }

    // calculate how many data transmissions are necessary
    transmissions = data_length / MAX_APDU_SEND_SIZE_T0 + (data_length % MAX_APDU_SEND_SIZE_T0 > 0 ? 1 : 0);

    offset = 0;
    lc = (MAX_APDU_SEND_SIZE_T0 < data_length ? MAX_APDU_SEND_SIZE_T0 : data_length);
    for (it = 0; it < transmissions; it++)
    {
        dwSendLength = sizeof(pbSendBuffer);
        r = apdu_build_command(CASE3, CLA_APPLICATION, INS_SET_ISSUER_SIGNATURES, it + 1, transmissions, lc, &data[offset], 0, pbSendBuffer, &dwSendLength);
        if (r < 0)
        {
            return -1;
        }

        dwRecvLength = sizeof(pbRecvBuffer);
        r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, NULL);
        if (r < 0)
        {
            fprintf(stderr, "Error: %s\n", sc_get_error(r));
            return r;
        }

        // get sw response
        apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
        if (r < 0)
        {
            return -1;
        }

        if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR && sw1sw2 != (uint16_t) CUSTOM_SW_EXPECTED_ADDITIONAL_DATA)
        {
            fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
            return -1;
        }

        offset += lc;
        lc = (offset + MAX_APDU_SEND_SIZE_T0 < data_length ? MAX_APDU_SEND_SIZE_T0 : data_length - offset);
    }

    return 0;
}

/**
 * Computes the proof of knowledge of the user attributes and discloses those requested
 * by the verifier using the remote reader.
 *
 * @param socket_id the socket identifier
 * @param sys_parameters the system parameters
 * @param ra_parameters the revocation authority parameters
 * @param ra_signature the signature of the user identifier
 * @param ie_signature the issuer signature
 * @param I the first pseudo-random value used to select the first randomizer
 * @param II the second pseudo-random value used to select the second randomizer
 * @param nonce the nonce generated by the verifier
 * @param nonce_length the length of the nonce
 * @param epoch the epoch generated by the verifier
 * @param epoch_length the length of the epoch
 * @param attributes the user attributes
 * @param str_seq_disclosed_attributes the sequence of attributes the verifier wants to disclose
 * @param credential the credential struct to be computed by the user
 * @param pi the pi struct to be computed by the user
 * @return 0 if success else -1
 */
int ue_remote_compute_proof_of_knowledge_seq_disclosing(int socket_id, system_par_t sys_parameters, revocation_authority_par_t ra_parameters, revocation_authority_signature_t ra_signature,
                                                               issuer_signature_t ie_signature, uint8_t I, uint8_t II, const void *nonce, size_t nonce_length, const void *epoch, size_t epoch_length,
                                                               user_attributes_t *attributes, char *str_seq_disclosed_attributes, user_credential_t *credential, user_pi_t *pi)
{
    uint8_t pbSendBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint8_t pbRecvBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint32_t dwSendLength;
    uint32_t dwRecvLength;

    uint8_t data[2048] = {0};
    size_t data_length;

    size_t transmissions;
    size_t offset;
    size_t lc, le;
    uint8_t p1, p2;
    uint16_t sw1sw2 = {0};

    int sequence_num_disclosed_attrib;
    uint8_t sequence_of_disclosed_attrib[P1_P2_LENGTH] = {0}; // IMPORTANT! order is P2, P1
    size_t num_non_disclosed_attributes;
    size_t num_disclosed_attributes = 0;
    size_t num_received_attributes = 0;
    char delimiters[] = {" ,;"};
    char *pch;

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    unsigned char hash[SHA_DIGEST_PADDING + SHA_DIGEST_LENGTH] = {0};

    double elapsed_time;

    size_t it;
    int r;

    if (nonce == NULL || nonce_length == 0 || epoch == NULL || epoch_length == 0 || attributes == NULL || pi == NULL || credential == NULL)
    {
        return -1;
    }

    //attributes->num_attributes = 0;
    if (attributes->num_attributes == 0)
    {
        /*
         * IMPORTANT!
         *
         * The attributes are disclosed by the bits sequence.
         * The last 4 bits are reserved for the number of non disclosed (hidden) attributes.
         *
         * --------------P1-----------------    --------------P2-----------------
         * +---+---+---+---+---+---+---+---+    +---+---+---+---+---+---+---+---+
         * | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |    | 9 | X | X | X | no. D  attrib |
         * +---+---+---+---+---+---+---+---+    +---+---+---+---+---+---+---+---+
         * | 0 | 0 | 1 | 1 | 0 | 0 | 1 | 1 |    | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
         * +---+---+---+---+---+---+---+---+    +---+---+---+---+---+---+---+---+
         * | H | H | D | D | H | H | D | D |    | H | X | X | X |          0x02 |
         * +---+---+---+---+---+---+---+---+    +---+---+---+---+---+---+---+---+
         */

        pch = strtok(str_seq_disclosed_attributes, delimiters);

        while (pch != NULL)
        {
            sequence_num_disclosed_attrib = (int) strtol(pch, NULL, 10);

            if (sequence_num_disclosed_attrib > USER_MAX_NUM_ATTRIBUTES || sequence_num_disclosed_attrib < 1 || num_disclosed_attributes > USER_MAX_NUM_ATTRIBUTES)
            {
                fprintf(stderr, "Error: wrong value for disclosed attribute: %d\n", sequence_num_disclosed_attrib);
                return -1;
            }
            if (!attributes->attributes[sequence_num_disclosed_attrib - 1].disclosed)
            {
                attributes->attributes[sequence_num_disclosed_attrib - 1].disclosed = true;
                num_disclosed_attributes++;
            }

            pch = strtok(NULL, delimiters);
        }

        // disclose attributes
        multos_attrib_seq_to_P1_P2(sequence_of_disclosed_attrib, attributes, num_disclosed_attributes);
        p1 = sequence_of_disclosed_attrib[1];
        p2 = sequence_of_disclosed_attrib[0];

        /// send disclosed attributes sequence and get this attribute back
        data_length = num_disclosed_attributes * sizeof(elliptic_curve_fr_t) + 1; // disclosed attributes

        // calculate how many data transmissions are necessary
        transmissions = data_length / MAX_APDU_SEND_SIZE_T0 + (data_length % MAX_APDU_SEND_SIZE_T0 > 0 ? 1 : 0);

        offset = 0;
        le = (MAX_APDU_SEND_SIZE_T0 < data_length ? ((int) (MAX_APDU_SEND_SIZE_T0 / (sizeof(elliptic_curve_fr_t)) * sizeof(elliptic_curve_fr_t)) + 1) : data_length);
        for (it = 0; it < transmissions; it++)
        {
            if (it != 0)
            {
                p1 = num_received_attributes;
                p2 = 0;
            }

            dwSendLength = sizeof(pbSendBuffer);
            r = apdu_build_command(CASE2, CLA_APPLICATION, INS_GET_USER_DISCLOSED_ATTRIBUTES, p1, p2, 0, data, le, pbSendBuffer, &dwSendLength);
            if (r < 0)
            {
                return -1;
            }

            dwRecvLength = sizeof(pbRecvBuffer);
            r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, &elapsed_time);
            if (r < 0)
            {
                fprintf(stderr, "Error: %s\n", sc_get_error(r));
                return r;
            }

            // get sw response
            apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
            if (r < 0)
            {
                return -1;
            }

            if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR && sw1sw2 != (uint16_t) CUSTOM_SW_EXPECTED_ADDITIONAL_DATA)
            {
                fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
                return -1;
            }

            // expected length
            //assert(dwRecvLength == le + 2);
            if (dwRecvLength != le + 2)
            {
                fprintf(stderr, "Error: wrong APDU response!\n");
                return -1;
            }

            // copy received data
            memcpy((void *) &data[offset], (const void *) pbRecvBuffer, dwRecvLength - 2);

            offset += le;
            num_received_attributes = offset / sizeof(elliptic_curve_fr_t);
            data_length -= le; // subtract the amount of data to be received
            le = (MAX_APDU_SEND_SIZE_T0 < data_length ? ((int) (MAX_APDU_SEND_SIZE_T0 / sizeof(elliptic_curve_fr_t)) * sizeof(elliptic_curve_fr_t)) : data_length);

            printf("[!] Elapsed time (get disclosed attributes) = %f\n", elapsed_time);
        }

        data_length = 0;

        // copy number of attributes
        attributes->num_attributes = data[data_length++];
        // copy attributes
        for (it = 0; it < attributes->num_attributes; it++)
        {
            if (attributes->attributes[it].disclosed)
            {
                memcpy(&attributes->attributes[it].value, &data[data_length], sizeof(elliptic_curve_fr_t));
                data_length += sizeof(elliptic_curve_fr_t);
            }
        }
    }
    else if (attributes->num_attributes <= USER_MAX_NUM_ATTRIBUTES)
    {
        /*
         * IMPORTANT!
         *
         * The attributes are disclosed by the bits sequence.
         * The last 4 bits are reserved for the number of non disclosed (hidden) attributes.
         *
         * --------------P1-----------------    --------------P2-----------------
         * +---+---+---+---+---+---+---+---+    +---+---+---+---+---+---+---+---+
         * | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |    | 9 | X | X | X | no. H  attrib |
         * +---+---+---+---+---+---+---+---+    +---+---+---+---+---+---+---+---+
         * | 0 | 0 | 1 | 1 | 0 | 0 | 1 | 1 |    | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 1 |
         * +---+---+---+---+---+---+---+---+    +---+---+---+---+---+---+---+---+
         * | H | H | D | D | H | H | D | D |    | H | X | X | X |          0x05 |
         * +---+---+---+---+---+---+---+---+    +---+---+---+---+---+---+---+---+
         */

        pch = strtok(str_seq_disclosed_attributes, delimiters);

        while (pch != NULL)
        {
            sequence_num_disclosed_attrib = strtol(pch, NULL, 10);

            if (sequence_num_disclosed_attrib > attributes->num_attributes || sequence_num_disclosed_attrib < 1 || num_disclosed_attributes > attributes->num_attributes)
            {
                fprintf(stderr, "Error: wrong value for disclosed attribute: %d\n", sequence_num_disclosed_attrib);
                return -1;
            }
            if (!attributes->attributes[sequence_num_disclosed_attrib - 1].disclosed)
            {
                attributes->attributes[sequence_num_disclosed_attrib - 1].disclosed = true;
                num_disclosed_attributes++;
            }

            pch = strtok(NULL, delimiters);
        }

        /// disclose attributes
        num_non_disclosed_attributes = attributes->num_attributes - num_disclosed_attributes;
        multos_attrib_seq_to_P1_P2(sequence_of_disclosed_attrib, attributes, num_non_disclosed_attributes);
        p1 = sequence_of_disclosed_attrib[1];
        p2 = sequence_of_disclosed_attrib[0];

        /// send disclosed attributes sequence
        lc = 0;

        dwSendLength = sizeof(pbSendBuffer);
        r = apdu_build_command(CASE1, CLA_APPLICATION, CMD_TEST_BIT_CHECKER, p1, p2, lc, data, 0, pbSendBuffer, &dwSendLength);
        if (r < 0)
        {
            return -1;
        }

        dwRecvLength = sizeof(pbRecvBuffer);
        r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, &elapsed_time);
        if (r < 0)
        {
            fprintf(stderr, "Error: %s\n", sc_get_error(r));
            return r;
        }

        // get sw response
        apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
        if (r < 0)
        {
            return -1;
        }

        if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR)
        {
            fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
            return -1;
        }

        printf("[!] Elapsed time (sequence of disclosed attributes) = %f\n", elapsed_time);
    } else
        return -1;

    lc = 0;

    // nonce
    memcpy(&data[lc], nonce, nonce_length);
    lc += NONCE_LENGTH;

    // epoch
    memcpy(&data[lc], epoch, epoch_length);
    lc += EPOCH_LENGTH;

    dwSendLength = sizeof(pbSendBuffer);
    r = apdu_build_command(CASE3, CLA_APPLICATION, INS_COMPUTE_PROOF_OF_KNOWLEDGE_SEQ_DISCLOSED, p1, p2, lc, data, 0, pbSendBuffer, &dwSendLength);
    if (r < 0)
    {
        return -1;
    }

    // proof of knowledge
    dwRecvLength = sizeof(pbRecvBuffer);
    r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, &elapsed_time);
    if (r < 0)
    {
        fprintf(stderr, "Error: %s\n", sc_get_error(r));
        return r;
    }

    printf("[!] Elapsed time (compute_proof_of_knowledge) = %f\n", elapsed_time);

    /// get user pi
    data_length = SHA_DIGEST_LENGTH + 2 * sizeof(elliptic_curve_multiplier_t) + 2 * sizeof(elliptic_curve_fr_t) + // e + s_v + s_i + s_e1 + s_e2 +
                  sizeof(elliptic_curve_fr_t) + (attributes->num_attributes - num_disclosed_attributes) * sizeof(elliptic_curve_fr_t); // s_mr + s_mz non-disclosed attributes

    // calculate how many data transmissions are necessary
    transmissions = data_length / MAX_APDU_SEND_SIZE_T0 + (data_length % MAX_APDU_SEND_SIZE_T0 > 0 ? 1 : 0);

    offset = 0;
    le = (MAX_APDU_SEND_SIZE_T0 < data_length ? MAX_APDU_SEND_SIZE_T0 : data_length);
    for (it = 0; it < transmissions; it++)
    {
        dwSendLength = sizeof(pbSendBuffer);
        r = apdu_build_command(CASE2, CLA_APPLICATION, INS_GET_PROOF_OF_KNOWLEDGE, 0x01, transmissions, 0, NULL, le, pbSendBuffer, &dwSendLength);
        if (r < 0)
        {
            return -1;
        }

        dwRecvLength = sizeof(pbRecvBuffer);
        r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, &elapsed_time);
        if (r < 0)
        {
            fprintf(stderr, "Error: %s\n", sc_get_error(r));
            return r;
        }

        printf("[!] Elapsed time (communication_proof_of_knowledge) = %f\n", elapsed_time);

        // get sw response
        apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
        if (r < 0)
        {
            return -1;
        }

        if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR && sw1sw2 != (uint16_t) CUSTOM_SW_EXPECTED_ADDITIONAL_DATA)
        {
            fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
            return -1;
        }

        // expected length
        //assert(dwRecvLength == le + 2);
        if (dwRecvLength != le + 2)
        {
            fprintf(stderr, "Error: wrong APDU response!\n");
            return -1;
        }

        // copy received data
        memcpy((void *) &data[offset], (const void *) pbRecvBuffer, dwRecvLength - 2);

        offset += le;
        data_length -= le; // subtract the amount of data to be received
        le = (data_length > MAX_APDU_SEND_SIZE_T0 ? MAX_APDU_SEND_SIZE_T0 : data_length);
    }

    /// get user credential
    data_length = 6 * sizeof(elliptic_curve_point_t); // sigma_hat, sigma_hat_e1, sigma_hat_e2, sigma_minus_e1, sigma_minus_e2, pseudonym

    // calculate how many data transmissions are necessary
    transmissions = data_length / MAX_APDU_SEND_SIZE_T0 + (data_length % MAX_APDU_SEND_SIZE_T0 > 0 ? 1 : 0);

    le = (MAX_APDU_SEND_SIZE_T0 < data_length ? MAX_APDU_SEND_SIZE_T0 : data_length);
    for (it = 0; it < transmissions; it++)
    {
        dwSendLength = sizeof(pbSendBuffer);
        r = apdu_build_command(CASE2, CLA_APPLICATION, INS_GET_PROOF_OF_KNOWLEDGE, 0x02, transmissions, 0, NULL, le, pbSendBuffer, &dwSendLength);
        if (r < 0)
        {
            return -1;
        }

        dwRecvLength = sizeof(pbRecvBuffer);
        r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, &elapsed_time);
        if (r < 0)
        {
            fprintf(stderr, "Error: %s\n", sc_get_error(r));
            return r;
        }

        printf("[!] Elapsed time (communication_proof_of_knowledge) = %f\n", elapsed_time);

        // get sw response
        apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
        if (r < 0)
        {
            return -1;
        }

        if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR && sw1sw2 != (uint16_t) CUSTOM_SW_EXPECTED_ADDITIONAL_DATA)
        {
            fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
            return -1;
        }

        // expected length
        //assert(dwRecvLength == le + 2);
        if (dwRecvLength != le + 2)
        {
            fprintf(stderr, "Error: wrong APDU response!\n");
            return -1;
        }

        // copy received data
        memcpy((void *) &data[offset], (const void *) pbRecvBuffer, dwRecvLength - 2);

        offset += le;
        data_length -= le; // subtract the amount of data to be received
        le = (data_length > MAX_APDU_SEND_SIZE_T0 ? MAX_APDU_SEND_SIZE_T0 : data_length);
    }

    data_length = 0;

    /// e <-- H(...)
    memcpy(&hash[SHA_DIGEST_PADDING], &data[data_length], SHA_DIGEST_LENGTH);
    multos_Fr_to_mcl_Fr(&pi->e, hash, sizeof(elliptic_curve_fr_t));
    r = mclBnFr_isValid(&pi->e);
    if (r != 1)
    {
        return -1;
    }
    data_length += SHA_DIGEST_LENGTH;

    /// s values
    // s_v
    multos_Multiplier_to_mcl_Fr(&pi->s_v, &data[data_length], sizeof(elliptic_curve_multiplier_t));
    r = mclBnFr_isValid(&pi->s_v);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_multiplier_t);

    // s_i
    multos_Multiplier_to_mcl_Fr(&pi->s_i, &data[data_length], sizeof(elliptic_curve_multiplier_t));
    r = mclBnFr_isValid(&pi->s_i);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_multiplier_t);

    // s_e1
    multos_Fr_to_mcl_Fr(&pi->s_e1, &data[data_length], sizeof(elliptic_curve_fr_t));
    r = mclBnFr_isValid(&pi->s_e1);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_fr_t);

    // s_e2
    multos_Fr_to_mcl_Fr(&pi->s_e2, &data[data_length], sizeof(elliptic_curve_fr_t));
    r = mclBnFr_isValid(&pi->s_e2);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_fr_t);

    // s_mr
    multos_Fr_to_mcl_Fr(&pi->s_mr, &data[data_length], sizeof(elliptic_curve_fr_t));
    r = mclBnFr_isValid(&pi->s_mr);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_fr_t);

    // s_mz non-disclosed attributes
    for (it = 0; it < attributes->num_attributes; it++)
    {
        if (attributes->attributes[it].disclosed == false)
        {
            multos_Fr_to_mcl_Fr(&pi->s_mz[it], &data[data_length], sizeof(elliptic_curve_fr_t));
            r = mclBnFr_isValid(&pi->s_mz[it]);
            if (r != 1)
            {
                return -1;
            }
            data_length += sizeof(elliptic_curve_fr_t);
        }
    }

    /// signatures
    // sigma_hat
    multos_G1_to_mcl_G1(&credential->sigma_hat, &data[data_length], sizeof(elliptic_curve_point_t));
    r = mclBnG1_isValid(&credential->sigma_hat);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_point_t);

    // sigma_hat_e1
    multos_G1_to_mcl_G1(&credential->sigma_hat_e1, &data[data_length], sizeof(elliptic_curve_point_t));
    r = mclBnG1_isValid(&credential->sigma_hat_e1);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_point_t);

    // sigma_hat_e2
    multos_G1_to_mcl_G1(&credential->sigma_hat_e2, &data[data_length], sizeof(elliptic_curve_point_t));
    r = mclBnG1_isValid(&credential->sigma_hat_e2);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_point_t);

    // sigma_minus_e1
    multos_G1_to_mcl_G1(&credential->sigma_minus_e1, &data[data_length], sizeof(elliptic_curve_point_t));
    r = mclBnG1_isValid(&credential->sigma_minus_e1);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_point_t);

    // sigma_minus_e2
    multos_G1_to_mcl_G1(&credential->sigma_minus_e2, &data[data_length], sizeof(elliptic_curve_point_t));
    r = mclBnG1_isValid(&credential->sigma_minus_e2);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_point_t);

    // pseudonym
    multos_G1_to_mcl_G1(&credential->pseudonym, &data[data_length], sizeof(elliptic_curve_point_t));
    r = mclBnG1_isValid(&credential->pseudonym);
    if (r != 1)
    {
        return -1;
    }
    data_length += sizeof(elliptic_curve_point_t);

    // amount of data processed = amount of data received
    assert(data_length == offset);

    return 0;
}

/**
 * Gets and displays the proof of knowledge of the user attributes using the remote reader.
 *
 * @param socket_id the socket identifier
 * @return 0 if success else -1
 */
int ue_remote_display_proof_of_knowledge(int socket_id)
{
    uint8_t pbSendBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint8_t pbRecvBuffer[MAX_APDU_LENGTH_T0] = {0};
    uint32_t dwSendLength;
    uint32_t dwRecvLength;
    uint16_t sw1sw2 = {0};

    char *proof_of_knowledge_values[11] = {
            "t_verify", "t_revoke", "t_sig", "t_sig1", "t_sig2",
            "sigma_hat", "sigma_hat_e1", "sigma_hat_e2", "sigma_minus_e1", "sigma_minus_e2",
            "pseudonym"
    };

    mclBnG1 point;

    size_t it;
    int r;

    for (it = 0; it < 0x0B; it++)
    {
        dwSendLength = sizeof(pbSendBuffer);
        r = apdu_build_command(CASE2, CLA_APPLICATION, CMD_TEST_GET_PROOF_OF_KNOWLEDGE, it + 1, 0x0B, 0, NULL, sizeof(elliptic_curve_point_t), pbSendBuffer, &dwSendLength);
        if (r < 0)
        {
            return -1;
        }

        dwRecvLength = sizeof(pbRecvBuffer);
        r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, NULL);
        if (r < 0)
        {
            fprintf(stderr, "Error: %s\n", sc_get_error(r));
            return r;
        }

        // get sw response
        apdu_get_sw(pbRecvBuffer, dwRecvLength, &sw1sw2, sizeof(sw1sw2));
        if (r < 0)
        {
            return -1;
        }

        if (sw1sw2 != (uint16_t) ISO7816_SW_NO_ERROR)
        {
            fprintf(stderr, "Error ISO 7816: %02x\n", sw1sw2);
            return -1;
        }

        multos_G1_to_mcl_G1(&point, pbRecvBuffer, sizeof(elliptic_curve_point_t));
        r = mclBnG1_isValid(&point);
        if (r != 1)
        {
            fprintf(stderr, "proof_of_knowledge[%lu].%s\n", it, proof_of_knowledge_values[it]);
            return -1;
        }
        mcl_display_G1(proof_of_knowledge_values[it], point);
    }

    dwSendLength = sizeof(pbSendBuffer);
    r = apdu_build_command(CASE2, CLA_APPLICATION, CMD_TEST_GET_PROOF_OF_KNOWLEDGE, it + 1, 0x0B, 0, NULL, 4*sizeof(uint8_t), pbSendBuffer, &dwSendLength);
    if (r < 0)
    {
        return -1;
    }

    dwRecvLength = sizeof(pbRecvBuffer);
    r = ntw_transmit_data(socket_id, pbSendBuffer, dwSendLength, pbRecvBuffer, &dwRecvLength, NULL);
    if (r < 0)
    {
        fprintf(stderr, "Error: %s\n", sc_get_error(r));
        return r;
    }

    fprintf(stdout, "randomizers    : %02X", pbRecvBuffer[0]);
    fprintf(stdout, " %02X", pbRecvBuffer[1]);
    fprintf(stdout, " %02X", pbRecvBuffer[2]);
    fprintf(stdout, " %02X\n", pbRecvBuffer[3]);

    return 0;
}
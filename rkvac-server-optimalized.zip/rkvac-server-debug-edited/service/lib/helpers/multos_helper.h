/**
 *
 *  Copyright (C) 2020  Raul Casanova Marques
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef __RKVAC_PROTOCOL_MULTOS_HELPER_H_
#define __RKVAC_PROTOCOL_MULTOS_HELPER_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

#include <mcl/bn_c256.h>

#include "crypto/helpers/hex_helper.h"
#include "crypto/helpers/mcl_helper.h"
#include "crypto/include/types.h"
#include "crypto/include/models/user.h"

/**
 * Bit set
 *
 * @param target_var target variable
 * @param bit_number_to_act bit number to act upon 0-15 *
 *
 */
#define __bit_set(target_var, bit_number_to_act) ((target_var) ^= (1u << (8 * sizeof(uint16_t) - bit_number_to_act - 1)))

/**
 * Converts an array of bytes (multos fr) into the mclBnFr type.
 *
 * @param x mclBnFr data
 * @param buffer the buffer to be converted
 * @param buffer_length the length of the buffer
 * @return 0 if success else -1
 */
extern int multos_Fr_to_mcl_Fr(mclBnFr *x, const void *buffer, size_t buffer_length);

/**
 * Converts an array of bytes (multos multiplier) into the mclBnFr type.
 *
 * @param x mclBnFr data
 * @param buffer the buffer to be converted
 * @param buffer_length the length of the buffer
 * @return 0 if success else -1
 */
extern int multos_Multiplier_to_mcl_Fr(mclBnFr *x, const void *buffer, size_t buffer_length);

/**
 * Converts an array of bytes (multos point) into the mclBnG1 type.
 *
 * @param x mclBnG1 data
 * @param buffer the buffer to be converted
 * @param buffer_length the length of the buffer
 * @return 0 if success else -1
 */
extern int multos_G1_to_mcl_G1(mclBnG1 *x, const void *buffer, size_t buffer_length);

/**
 * Converts sequence of disclosed attributes into the P1, P2 parameters.
 *
 * @param p1 P1 parameter
 * @param p2 P2 parameter
 * @param attributes user attributes
 * @param num_hidden_attributes number of hidden attributes
 * @return 0 if success else -1
 */
extern multos_attrib_seq_to_P1_P2(uint8_t *param, user_attributes_t *attributes, unsigned int num_hidden_attributes);

#ifdef __cplusplus
}
#endif

#endif /* __RKVAC_PROTOCOL_MULTOS_HELPER_H_ */

/**
 *
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef __RKVAC_PROTOCOL_HELP_H
#define __RKVAC_PROTOCOL_HELP_H

#ifdef __cplusplus
extern "C"
{
#endif

#define SERVICE_HELP \
    "Usage: %s \n" \
    "******************************************************************************************************\n" \
    "* Select entity                                                                                      *\n" \
    "*   possible options for entity                                                                      *\n" \
    "******************************************************************************************************\n" \
    "Short options                  Long options                                Argument        Description\n" \
    "-p                             --personalization                           no argument     Create or update the User list file, generate user identifier and set it to the card.\n" \
    "  -n <char[]>                  --user-name=<char[]>                        required        The user name used for card personalization.\n" \
    "  -s <char[]>                  --user-surname=<char[]>                     required        The user surname used for card personalization.\n" \
    "                                                                                           \n" \
    "-r                             --revocation-authority                      no argument     Check or create Revocation authority files, revocation handlers file. Set revocation handler and RA parameters to the card.\n" \
    "  -e<path/filename>            --new-epoch=<path/filename>                 optional        Generate revocation database and blacklist for new epoch.\n" \
    "  -b <epoch SHA256(pseudonym)> --revoke-user-c=<epoch SHA256(pseudonym)>   required        Create blacklist for given epoch and pseudonym hash whitespace separated.\n" \
    "                                                                                           The string has to be written in quotes (e.g. \"56221020 bd815c...\").\n" \
    "  -B <epoch id>                --revoke-user-id=<epoch id>                 required        Create blacklist for given epoch and user id.\n" \
    "                                                                                           The string has to be written in quotes (e.g. \"56221020 1000000000000002\").\n" \
    "                                                                                           \n" \
    "-i                             --issuer                                    no argument     Check or create Issuer private keys file. Load RA public key file. Set user attributes signature to the card.\n" \
    "  -a <path/filename>           --set-attributes=<path/filename>            required        Obligatory option for Issuer. Load user attributes from defined file (or create file if it does not exist) and set it to the card.\n" \
    "                                                                                           \n" \
    "-v                             --verifier                                  no argument     Load user attributes file, RA public parameters file, RA public key file, IE private keys file. Verify proof of knowledge.\n" \
    "  -a <path/filename>           --set-attributes=<path/filename>            required        Load user attributes from defined file (or create file if it does not exist).\n" \
    "  -d <char[]>                  --disclosed-attributes=<char[]>             required        Disclosed attributes comma separated (e.g. 1 or 3,4,6). \n" \
    "  -e<path/filename>            --new-epoch=<path/filename>                 optional        Generate new epoch (ccDDMMYY, cc = counter 1..256).\n" \
    "  -u <path/filename>           --update-bl=<path/filename>                 required        Update blacklist.\n" \
    "  -w <path/filename>           --rewrite-bl=<path/filename>                required        Rewrite blacklist.\n" \
    "  -c <path/filename>           --create-credentials=<path/filename>        required        Save user attributes to the defined file (create or rewrite file).\n" \
    "                                                                                           \n" \

#ifdef __cplusplus
}
#endif

#endif //__RKVAC_PROTOCOL_HELP_H

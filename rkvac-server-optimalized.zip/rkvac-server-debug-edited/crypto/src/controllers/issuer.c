/**
 *
 *  Copyright (C) 2020  Raul Casanova Marques
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "issuer.h"

/**
* Get the user attributes from file.
*
* @param credentials the Issuer credentials
* @param ue_attributes the user attributes
* @param ie_user_attributes_file file with the user attributes. The file should be opened in mode "r".
*
* @return 0 if success else -1
*/
int ie_get_user_attributes(ie_credentials_t *credentials, user_attributes_t *ue_attributes, FILE *ie_user_attributes_file)
{
    char data[4096]= {0};
    char *pch;

    size_t it = 0;
    int r;

    if (ie_user_attributes_file == NULL )
    {
        fprintf(stderr, "Error: invalid ie_user_attributes file!\n");
        return -1;
    }

    if (credentials == NULL || ue_attributes == NULL)
    {
        fclose(ie_user_attributes_file);
        return -1;
    }

    r = read_data_from_file(ie_user_attributes_file, data, sizeof(data));
    if (r <= 0)
    {
        fprintf(stderr, "Error: invalid ie_user_attributes file!\n");
        fclose(ie_user_attributes_file);
        return -1;
    }
    else
    {
        pch = strtok(data, ";");

        while (pch != NULL)
        {
            fprintf(stdout, " [%d] %s: ", it + 1, pch);

            pch = strtok(NULL, ";");
            fprintf(stdout, "%s -> hash: ", pch);
            hex2mem((unsigned char *) credentials->ie_credentials_details.ue_attributes.ie_attributes_str_value[it].str_value, pch, EC_SIZE);

            pch = strtok(NULL, "\n");
            fprintf(stdout, "%s\n", pch);

            hex2mem(ue_attributes->attributes[it].value, pch, EC_SIZE);
            pch = strtok(NULL, ";");
            it++;
        }
        credentials->ie_credentials_details.ue_attributes.num_attributes = it;
        ue_attributes->num_attributes = it;
    }

    fclose(ie_user_attributes_file);
    return 0;
}

/**
 * Read or compute the issuer parameters, generates or load the private keys, load RA public key.
 *
 * @param parameters the issuer parameters
 * @param ie_private_keys the issuer private keys
 * @param ra_public_key the revocation authority public key.
 * @param ie_private_keys_file file with private keys x(0),x(1)...x(n-1).
 * @param ra_public_key_file file with ra public key. The file should be opened in mode "r".
 *
 * @return 0 if success else -1
 */
int ie_setup(issuer_par_t parameters, issuer_keys_t *ie_private_keys, revocation_authority_public_key_t *ra_public_key, FILE *ie_private_keys_file, FILE *ra_public_key_file)
{
    size_t it;
    int r;

    char data[4096]= {0};
    size_t data_length;
    char *pch;

    if (ie_private_keys_file == NULL || ra_public_key_file == NULL)
    {
        if (ie_private_keys_file != NULL)
            fclose(ie_private_keys_file);
        else
            fprintf(stderr, "Error: invalid ie_private keys file!\n");
        if (ra_public_key_file != NULL)
            fclose(ra_public_key_file);
        else
            fprintf(stderr, "Error: invalid ra_public key file!\n");

        return -1;
    }

    if (ie_private_keys == NULL || ra_public_key == NULL || parameters.num_attributes == 0 || parameters.num_attributes > USER_MAX_NUM_ATTRIBUTES)
    {
        fclose(ie_private_keys_file);
        fclose(ra_public_key_file);
        return -1;
    }


    /// load revocation authority public key from file
    r = read_data_from_file(ra_public_key_file, data, sizeof(data));
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid ra_public_key file!\n");
        fclose(ra_public_key_file);
        fclose(ie_private_keys_file);
        return -1;
    }
    else
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading ra_public key from file.\n");
# endif

        data_length = r;
        r = mclBnG2_setStr(&ra_public_key->pk, (const char *) data, data_length, 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ra_public_key file!\n");
            fclose(ra_public_key_file);
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnG2_isValid(&ra_public_key->pk);
        if (r == 0)
        {
            fprintf(stderr, "Error: invalid ra_public_key file!\n");
            fclose(ra_public_key_file);
            fclose(ie_private_keys_file);
            return -1;
        }
    }
    fclose(ra_public_key_file);

    /// issuer private keys
    r = read_data_from_file(ie_private_keys_file, data, sizeof(data));
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid ie_private_keys file!\n");
        fclose(ie_private_keys_file);
        return -1;
    }
    else if (r == 0)
    {
        /// generate ie private key - x(0), x(1)...x(n-1), x(r) and write them to the file
# ifndef NDEBUG
        fprintf(stdout, "[+] Generating ie private key - x(0), x(1)...x(n-1), x(r).\n");
# endif
        // issuer private key - x(0)
        mclBnFr_setByCSPRNG(&ie_private_keys->issuer_private_key.sk);
        r = mclBnFr_isValid(&ie_private_keys->issuer_private_key.sk);
        if (r != 1)
        {
            fclose(ie_private_keys_file);
            return -1;
        }

        // write issuer private key - x(0)
        r = mclBnFr_getStr(data, sizeof(data), &ie_private_keys->issuer_private_key.sk, 16);
        if (r == 0)
        {
            fclose(ie_private_keys_file);
            return -1;
        }
        data_length = r;
        strcat(data, "\n");
        data_length++;

        // private keys - x(1)...x(n-1)
        for (it = 0; it < USER_MAX_NUM_ATTRIBUTES; it++)
        {
            mclBnFr_setByCSPRNG(&ie_private_keys->attribute_private_keys[it].sk);
            r = mclBnFr_isValid(&ie_private_keys->attribute_private_keys[it].sk);
            if (r != 1)
            {
                return -1;
            }

            // write private keys - x(1)...x(n-1)
            r = mclBnFr_getStr(&data[data_length], sizeof(data) - data_length, &ie_private_keys->attribute_private_keys[it].sk, 16);
            if (r == 0)
            {
                fclose(ie_private_keys_file);
                return -1;
            }
            data_length += r;
            data[data_length] = '\n';
            data_length++;
        }

        // revocation private key - x(r)
        mclBnFr_setByCSPRNG(&ie_private_keys->revocation_private_key.sk);
        r = mclBnFr_isValid(&ie_private_keys->revocation_private_key.sk);
        if (r != 1)
        {
            fclose(ie_private_keys_file);
            return -1;
        }

        // write revocation private key - x(r)
        r = mclBnFr_getStr(&data[data_length], sizeof(data) - data_length, &ie_private_keys->revocation_private_key.sk, 16);
        if (r == 0)
        {
            fclose(ie_private_keys_file);
            return -1;
        }
        data_length += r;
        data[data_length] = '\n';
        data_length++;

        r = write_data_to_file(ie_private_keys_file, data, data_length);
        if (r < data_length)
        {
            fprintf(stderr, "Error: writing data to ie_private_keys.dat file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }
    }
    else
    {
        /// load ie private key - x(0), x(1)...x(n-1), x(r) from file
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading ie_private keys from file.\n");
# endif
        // issuer private key - x(0)
        pch = strtok(data, "\n");
        if (pch == NULL)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnFr_setStr(&ie_private_keys->issuer_private_key.sk, (const char *) pch, strlen(pch), 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnFr_isValid(&ie_private_keys->issuer_private_key.sk);
        if (r != 1)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        // private keys - x(1)...x(n-1)
        for (it = 0; it < USER_MAX_NUM_ATTRIBUTES; it++)
        {
            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ie_private_keys file!\n");
                fclose(ie_private_keys_file);
                return -1;
            }

            r = mclBnFr_setStr(&ie_private_keys->attribute_private_keys[it].sk, (const char *) pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ie_private_keys file!\n");
                fclose(ie_private_keys_file);
                return -1;
            }

            r = mclBnFr_isValid(&ie_private_keys->attribute_private_keys[it].sk);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid ie_private_keys file!\n");
                fclose(ie_private_keys_file);
                return -1;
            }
        }

        // revocation private key - x(r)
        pch = strtok(NULL, "\n");
        if (pch == NULL)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnFr_setStr(&ie_private_keys->revocation_private_key.sk, (const char *) pch, strlen(pch), 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }

        r = mclBnFr_isValid(&ie_private_keys->revocation_private_key.sk);
        if (r != 1)
        {
            fprintf(stderr, "Error: invalid ie_private_keys file!\n");
            fclose(ie_private_keys_file);
            return -1;
        }
    }

    fclose(ie_private_keys_file);

    return 0;
}

/**
 * Outputs the user identifier.
 *
 * @param identifier the user identifier
 * @param user_list the user list file
 * @return 0 if success else -1
 */
int ie_generate_user_identifier(user_identifier_t *identifier, FILE *user_list)
{
    int r;
    size_t it;

    char line_string[MAX_INPUT];
    char string_identifier[2 * USER_MAX_ID_LENGTH + 1];
    char *pch;

    if (identifier == NULL || user_list == NULL)
    {
        return -1;
    }

    /// Read user identifier from user_list
    /*
     * IMPORTANT!
     *
     * The user list must be sorted by identifier from smallest to largest.
     *
     * File structure!
     * +---+---+---+---+---+---+---+---+
     * 10000000000000001;user name 1 ; user surname 1
     * 10000000000000002;user name 2 ; user surname 2
     * ...
     * user id n ;user name n ; user surname n
     *
     * +---+---+---+---+---+---+---+---+
     *
     */
# ifndef NDEBUG
    fprintf(stdout, "[+] Reading the last identifier from the user list.\n");
# endif
    r = load_last_line (user_list, line_string);
    if (r == 1) // user_list is empty, generate first identifier 10 00 .. 00 01
    {
        identifier->buffer_length = USER_MAX_ID_LENGTH;
        memset(identifier->buffer, 0, USER_MAX_ID_LENGTH);
        identifier->buffer[0] = 0x10;
        identifier->buffer[USER_MAX_ID_LENGTH - 1] = 0x01;
    }
    else if (r == 0) // user_list is not empty, read last identifier and increase value
    {
        pch = strtok(line_string, ";");

        if (strlen(pch) > sizeof(string_identifier))
        {
            fprintf(stderr, "Error: invalid user list\n");
            fclose(user_list);
            return -1;
        }
        identifier->buffer_length = USER_MAX_ID_LENGTH;
        hex2mem(identifier->buffer, pch, USER_MAX_ID_LENGTH);

        for(it = 1; it <= USER_MAX_ID_LENGTH; it++)
        {
            identifier->buffer[USER_MAX_ID_LENGTH - it] += 1u;

            if (identifier->buffer[USER_MAX_ID_LENGTH - it] != 0x00)
                break;
        }
    }
    else
    {
        fclose(user_list);
        return -1;
    }

    mem2hex(string_identifier, identifier->buffer, identifier->buffer_length);

    // check if the increment identifier doesn't exist
# ifndef NDEBUG
    fprintf(stdout, "[+] Checking if the increment identifier doesn't exist.\n");
# endif
    r = search_text_in_column(user_list, string_identifier, 1);
    if (r < 0)
    {
        return -1;
    }
    else if (r == 0)
    {
        fprintf(stderr, "Error: user list contain the same identifier!\n");
        fclose(user_list);
        return -1;
    }

    fclose(user_list);
    user_list = NULL;
# ifndef NDEBUG
    fprintf(stdout, "\n");
# endif
    return 0;
}

/**
 * Set the user identifier to the user list file.
 *
 * @param identifier the user identifier
 * @param user_list the user list file
 * @param ue_name user name
 * @param ue_surname user surname
 *
 * @return 0 if success else -1
 */
int ie_set_user_identifier(user_identifier_t *identifier, FILE *user_list, char *ue_name, char *ue_surname) {

    char data[MAX_INPUT];

    int r;

    if (user_list == NULL)
    {
        fprintf(stderr, "Error: invalid user list file!\n");
        return -1;
    }

    if (identifier == NULL || ue_name == NULL || ue_surname == NULL)
    {
        fclose(user_list);
        return -1;
    }

    mem2hex(data, identifier->buffer, identifier->buffer_length);
    strcat(data,";");
    strcat(data, ue_name);
    strcat(data, ";");
    strcat(data, ue_surname);
    strcat(data, "\n");

    r = write_data_to_file(user_list, data, strlen(data));
    if (r < strlen(data))
    {
        fprintf(stderr, "Error: writing data to user list!\n");
        fclose(user_list);
        return -1;
    }

    fclose(user_list);
    return 0;
}

/**
 * Get the user name and surname from the user list file.
 *
 * @param identifier the user identifier
 * @param user_list the user list file
 * @param ue_name user name
 * @param ue_surname user surname
 *
 * @return 0 if success else -1
 */
int ie_get_user_full_name(user_identifier_t identifier, FILE *user_list, char *ue_name, char *ue_surname)
{
    char data[MAX_INPUT];
    char str_identifier[2 * USER_MAX_ID_LENGTH + 1];
    char *token;

    int r;

    if (user_list == NULL)
    {
        fprintf(stderr, "Error: invalid user list file!\n");
        return -1;
    }

    if (ue_name == NULL || ue_surname == NULL)
    {
        fclose(user_list);
        return -1;
    }

    // convert identifier to string
    mem2hex(str_identifier, identifier.buffer, identifier.buffer_length);

    // find identifier
    r = get_line_text(data, str_identifier, sizeof(data), user_list);
    if (r < 0)
    {
        fclose(user_list);
        return -1;
    }
    else if (r == 1)
    {
        fprintf(stderr, "Error: user list does not contain %s identifier!\n", str_identifier);
        fclose(user_list);
        return -1;
    }
    fclose(user_list);

    token = strtok(data, ";");
    if (token == NULL)
        return -1;

    // get user name
    token = strtok(NULL, ";");
    if (token == NULL)
    {
        return -1;
    }

    strcpy(ue_name, token);

    // get user surname
    token = strtok(NULL, ";\n");
    if (token == NULL)
    {
        return -1;
    }

    strcpy(ue_surname, token);

    return 0;
}

/**
 * Outputs the SHA256(user attribute).
 *
 * @param credentials issuer credentials
 * @param ue_attribute_value 256bits hash of the user attribute
 *
 * @return 0 if success else -1
 */
int ie_generate_user_attribute(ie_attribute_str_value_t str_attributes, uint8_t *attribute_value)
{
    int r;

    mclBnFr fr_attribute;

    if (attribute_value == NULL)
    {
        return -1;
    }

    // set SHA256(string attribute)
    r = mclBnFr_setHashOf(&fr_attribute, str_attributes.str_value, strlen(str_attributes.str_value));
    if (r != 0)
    {
        return -1;
    }

    r = mclBnFr_isValid(&fr_attribute);
    if (r != 1)
    {
        return -1;
    }

    mcl_Fr_to_bytes(attribute_value, EC_SIZE, fr_attribute);

    return 0;
}

/**
 * Set the user attributes to file.
 *
 * @param credentials issuer credentials
 * @param ue_attributes the user attributes
 * @param ie_user_attributes_file empty file to write user attributes. The file must be opened in mode "w".
 *
 * @return 0 if success else -1
 */
int ie_set_user_attributes(ie_credentials_t credentials, user_attributes_t ue_attributes,FILE *ie_user_attributes_file)
{
    char data[4096];

    int r;
    size_t it;
    size_t data_length = 0;


    if (ie_user_attributes_file == NULL)
    {
        fprintf(stderr, "Error: invalid user attribute file!\n");
        return -1;
    }

    // write user attributes
    for (it = 0; it < credentials.ie_credentials_details.ue_attributes.num_attributes; it++)
    {
        strcpy(&data[data_length], credentials.ie_credentials_details.ie_credentials_name[it].name);
        data_length += strlen(credentials.ie_credentials_details.ie_credentials_name[it].name);
        strcat(data, ";");
        data_length++;
        strcpy(&data[data_length], credentials.ie_credentials_details.ue_attributes.ie_attributes_str_value[it].str_value);
        data_length += strlen(credentials.ie_credentials_details.ue_attributes.ie_attributes_str_value[it].str_value);
        strcat(data, ";");
        data_length++;
        mem2hex(&data[data_length], ue_attributes.attributes[it].value, EC_SIZE);
        data_length += 2 * EC_SIZE;
        strcat(data, "\n");
        data_length++;
    }
# ifndef NDEBUG
    fprintf(stdout, "[+] Writing the user attributes to the file.\n\n");
# endif

    if (data_length > sizeof(data))
    {
        fclose(ie_user_attributes_file);
        return -1;
    }

    r = write_data_to_file(ie_user_attributes_file, data, data_length);
    if (r != data_length)
    {
        fclose(ie_user_attributes_file);
        return -1;
    }

    fclose(ie_user_attributes_file);
    return 0;
}

/**
 * Computes the signature of the user attributes using the private keys.
 *
 * @param sys_parameters the system parameters
 * @param parameters the issuer parameters
 * @param keys the issuer keys
 * @param ra_public_key the revocation authority public key.
 * @param ue_identifier the user identifier
 * @param ue_attributes the user attributes
 * @param revocation_authority_signature the revocation authority signature (mr, ra_sigma)
 * @param signature the signature of the user attributes
 *
 * @return 0 if success else -1
 */
int ie_issue(system_par_t sys_parameters, issuer_par_t parameters, issuer_keys_t keys, revocation_authority_public_key_t ra_public_key, user_identifier_t ue_identifier, user_attributes_t ue_attributes,
             revocation_authority_signature_t revocation_authority_signature, issuer_signature_t *signature)
{
    mclBnGT el, er;
    mclBnGT e1, e2, e3;

    mclBnFr number_one, attribute;
    mclBnFr add_result, mul_result, div_result;

    unsigned char fr_data[EC_SIZE];
    mclBnFr fr_hash;
    char data[1024]= {0};
    size_t data_length;

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    unsigned char hash[SHA_DIGEST_PADDING + SHA_DIGEST_LENGTH] = {0};
    SHA_CTX ctx;

    size_t it;
    int r;

    if (ue_attributes.num_attributes == 0 || ue_attributes.num_attributes > USER_MAX_NUM_ATTRIBUTES || signature == NULL)
    {
        return -1;
    }

    // signature->mr to bytes
    mcl_Fr_to_bytes(fr_data, EC_SIZE, revocation_authority_signature.mr);

    // H(mr || id)
    SHA1_Init(&ctx);
    SHA1_Update(&ctx, fr_data, EC_SIZE);
    SHA1_Update(&ctx, ue_identifier.buffer, ue_identifier.buffer_length);
    SHA1_Final(&hash[SHA_DIGEST_PADDING], &ctx);

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    mcl_bytes_to_Fr(&fr_hash, hash, EC_SIZE);
    r = mclBnFr_isValid(&fr_hash);
    if (r != 1)
    {
        return -1;
    }

    /// pairing
    // e(ra_sigma, ra_pk)
    mclBn_pairing(&e1, &revocation_authority_signature.sigma, &ra_public_key.pk);

    // e(ra_sigma^hash, G2) == e(ra_sigma, G2)^hash
    mclBn_pairing(&e2, &revocation_authority_signature.sigma, &sys_parameters.G2);
    mclBnGT_pow(&e3, &e2, &fr_hash);

    // e(ra_sigma, ra_pk) * e(ra_sigma^hash, G2)
    mclBnGT_mul(&el, &e1, &e3);

    // e(G1, G2)
    mclBn_pairing(&er, &sys_parameters.G1, &sys_parameters.G2);

    // e(ra_sigma, ra_pk) * e(ra_sigma^hash, G2) ?= e(G1, G2)
    r = mclBnGT_isEqual(&el, &er);
    if (r != 1)
    {
        fprintf(stderr, "Error: bilinear pairing!\n");
        return -1;
    }

    /// signature of the user attributes
    // set 1 to Fr data type
    mclBnFr_setInt32(&number_one, 1);

    // add_result = x(0)
    memcpy(&add_result, &keys.issuer_private_key.sk, sizeof(mclBnFr));
    // add_result = add_result + m(it)·x(it)
    for (it = 0; it < parameters.num_attributes; it++)
    {
        mcl_bytes_to_Fr(&attribute, ue_attributes.attributes[it].value, EC_SIZE);
        mclBnFr_mul(&mul_result, &attribute, &keys.attribute_private_keys[it].sk);
        mclBnFr_add(&add_result, &add_result, &mul_result);
    }
    // add_result = add_result + m(r)·x(r)
    mclBnFr_mul(&mul_result, &revocation_authority_signature.mr, &keys.revocation_private_key.sk);
    mclBnFr_add(&add_result, &add_result, &mul_result);

    mclBnFr_div(&div_result, &number_one, &add_result); // div_result = 1 / add_result
    mclBnG1_mul(&signature->sigma, &sys_parameters.G1, &div_result); // sigma = G1 * div_result
    mclBnG1_normalize(&signature->sigma, &signature->sigma);
    r = mclBnG1_isValid(&signature->sigma);
    if (r != 1)
    {
        return -1;
    }

    /// sigma attributes
    // sigma_x_it = sigma·x_it
    for (it = 0; it < parameters.num_attributes; it++)
    {
        mclBnG1_mul(&signature->attribute_sigmas[it], &signature->sigma, &keys.attribute_private_keys[it].sk);
        mclBnG1_normalize(&signature->attribute_sigmas[it], &signature->attribute_sigmas[it]);
        r = mclBnG1_isValid(&signature->attribute_sigmas[it]);
        if (r != 1)
        {
            fprintf(stderr, "Error: sigma for x_%d is not valid!\n", it);
            return -1;
        }
    }

    mclBnG1_mul(&signature->revocation_sigma, &signature->sigma, &keys.revocation_private_key.sk);
    mclBnG1_normalize(&signature->revocation_sigma, &signature->revocation_sigma);
    r = mclBnG1_isValid(&signature->revocation_sigma);
    if (r != 1)
    {
        fprintf(stderr, "Error: sigma for x_r is not valid!\n");
        return -1;
    }

    return 0;
}

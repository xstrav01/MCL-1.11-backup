/**
 *
 *  Copyright (C) 2020  Raul Casanova Marques
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "revocation-authority.h"

/**
 * Read or compute the revocation authority parameters, generates or load the
 * private key and computes or load the public key.
 *
 * @param sys_parameters the system parameters
 * @param parameters the revocation authority parameters
 * @param keys the revocation authority private and public keys
 * @param ra_parameters_file file with ra parameters.
 * @param ra_public_parameters_file file with ra public parameters (aplhas_mul[1]...aplhas_mul[j] as h_j).
 * @param ra_public_key_file file with ra public key.
 * @param ra_private_key_file file with ra private key.
 *
 * @return 0 if success else -1
 */
int ra_setup(system_par_t sys_parameters, revocation_authority_par_t *parameters, revocation_authority_keys_t *keys,
             FILE *ra_parameters_file, FILE *ra_public_parameters_file, FILE *ra_public_key_file, FILE *ra_private_key_file)
{
    mclBnFr number_one;
    mclBnFr add_result, div_result;
    mclBnG2 pk_validation;

    char data[4096]= {0};
    char public_data[4096]= {0};
    char *pch;
    size_t data_length;
    size_t public_data_length = 0;

    bool param_generate = false;
    bool pk_generate = false;
    bool sk_generate = false;

    size_t it;
    int r;

    if (ra_parameters_file == NULL || ra_private_key_file == NULL || ra_public_key_file == NULL || ra_public_parameters_file == NULL)
    {
        if (ra_parameters_file != NULL)
            fclose(ra_parameters_file);

        if (ra_public_parameters_file != NULL)
            fclose(ra_public_parameters_file);

        if (ra_private_key_file != NULL)
            fclose(ra_private_key_file);

        if (ra_public_key_file != NULL)
            fclose(ra_public_key_file);

        return -1;
    }

    if (parameters == NULL || keys == NULL)
    {
        fclose(ra_parameters_file);
        fclose(ra_public_parameters_file);
        fclose(ra_public_key_file);
        fclose(ra_private_key_file);
        return -1;
    }

    /// read public key from file
    r = read_data_from_file(ra_public_key_file, data, sizeof(data));
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid ra_public_key file!\n");
        fclose(ra_parameters_file);
        fclose(ra_public_parameters_file);
        fclose(ra_public_key_file);
        fclose(ra_private_key_file);
        return -1;
    }
    else if (r == 0)
    {
        pk_generate = true;
    }
    else
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading ra_public key from file.\n");
# endif

        data_length = r;
        r = mclBnG2_setStr(&keys->public_key.pk, (const char *) data, data_length, 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ra_public_key file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }

        r = mclBnG2_isValid(&keys->public_key.pk);
        if (r == 0)
        {
            fprintf(stderr, "Error: invalid ra_public_key file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }
    }

    /// read private key from file
    r = read_data_from_file(ra_private_key_file, data, sizeof(data));
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid ra_private_key file!\n");
        fclose(ra_parameters_file);
        fclose(ra_public_parameters_file);
        fclose(ra_public_key_file);
        fclose(ra_private_key_file);
        return -1;
    }
    else if (r == 0)
    {
        sk_generate = true;
    }
    else
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading ra_private key from file.\n");
# endif

        data_length = r;
        r = mclBnFr_setStr(&keys->private_key.sk, (const char *) data, data_length, 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ra_private_key file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }

        r = mclBnFr_isValid(&keys->private_key.sk);
        if (r == 0)
        {
            fprintf(stderr, "Error: invalid ra_private_key file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }
        mclBnG2_mul(&pk_validation, &sys_parameters.G2, &keys->private_key.sk);
        mclBnG2_normalize(&pk_validation, &pk_validation);
        r = mclBnG2_isEqual(&pk_validation, &keys->public_key.pk);
        if (r != 1)
        {
            fprintf(stderr, "Error: invalid ra_private_key file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }
    }

    if (pk_generate && sk_generate)
    {
        /// computes RA key pair
# ifndef NDEBUG
        fprintf(stdout, "[+] Generating new ra_keys.\n");
# endif
        // private key
        mclBnFr_setByCSPRNG(&keys->private_key.sk);
        r = mclBnFr_isValid(&keys->private_key.sk);
        if (r != 1)
        {
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }

        // write private key to file
        r = mclBnFr_getStr(data, sizeof(data), &keys->private_key.sk, 16);
        if (r == 0)
        {
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }
# ifndef NDEBUG
        fprintf(stdout, "[!] Writing ra_private_key to file.\n");
# endif
        data_length = r;
        r = write_data_to_file(ra_private_key_file, data, data_length);
        if (r < data_length)
        {
            fprintf(stderr, "Error: writing data to ra_private_key.dat file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }

        // public key (multiplication in elliptic curves)
        mclBnG2_mul(&keys->public_key.pk, &sys_parameters.G2, &keys->private_key.sk);
        mclBnG2_normalize(&keys->public_key.pk, &keys->public_key.pk);
        r = mclBnG2_isValid(&keys->public_key.pk);
        if (r != 1)
        {
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }

        // write public key to file
        r = mclBnG2_getStr(data, sizeof(data), &keys->public_key.pk, 16);
        if (r == 0)
        {
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }
# ifndef NDEBUG
        fprintf(stdout, "[!] Writing ra_public_key to file.\n");
# endif
        data_length = r;
        r = write_data_to_file(ra_public_key_file, data, data_length);
        if (r < data_length)
        {
            fprintf(stderr, "Error: writing data to ra_public_key.dat file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            fclose(ra_public_key_file);
            fclose(ra_private_key_file);
            return -1;
        }
    }
    else if (pk_generate || sk_generate)
    {
        fprintf(stderr, "Error: invalid ra_private_key or ra_public_key file!\n");
        fclose(ra_parameters_file);
        fclose(ra_public_parameters_file);
        fclose(ra_public_key_file);
        fclose(ra_private_key_file);
        return -1;
    }

    fclose(ra_public_key_file);
    fclose(ra_private_key_file);

    /// load ra parameters from file
    /*
     * File structure!
     * +---+---+---+---+---+---+---+---+
     * k
     * j
     * parameters->alphas[1]
     * parameters->alphas_mul[1]
     * ...
     * parameters->alphas[j]
     * parameters->alphas_mul[j]
     * parameters->randomizers[1]
     * parameters->randomizers_sigma[1]
     * ...
     * parameters->randomizers[k]
     * parameters->randomizers_sigma[k]
     * +---+---+---+---+---+---+---+---+
     *
     */
    r = read_data_from_file(ra_parameters_file,data, sizeof(data));
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid ra_parameters file!\n");
        fclose(ra_parameters_file);
        fclose(ra_public_parameters_file);
        return -1;
    }
    else if (r == 0)
    {
        param_generate = true;
    }
    else
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading ra_parameters from file.\n");
# endif

        // read integers (k, j)
        r = 0;
        pch = strtok(data, "\n");
        if (pch == NULL)
        {
            fprintf(stderr, "Error: invalid ra_parameters file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            return -1;
        }
        hex2mem((unsigned char *) &parameters->k, pch, strlen(pch));
        if (parameters->k != REVOCATION_AUTHORITY_VALUE_K)
            r = -1;
        pch = strtok(NULL, "\n");
        hex2mem((unsigned char *) &parameters->j, pch, strlen(pch));
        if (parameters->j != REVOCATION_AUTHORITY_VALUE_J)
            r = -1;
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ra_parameters file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            return -1;
        }

        // read random integers (alphas)
        for (it = 0; it < parameters->j; it++)
        {
            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            r = mclBnFr_setStr(&parameters->alphas[it], (const char *) pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            r = mclBnFr_isValid(&parameters->alphas[it]);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            r = mclBnG1_setStr(&parameters->alphas_mul[it], pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            r = mclBnG1_isValid(&parameters->alphas_mul[it]);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }
        }

        // read randomizers and their signs
        for (it = 0; it < parameters->k; it++)
        {
            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            r = mclBnFr_setStr(&parameters->randomizers[it], (const char *) pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }
            r = mclBnFr_isValid(&parameters->randomizers[it]);
            if (r != 1)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            // randomizers_sigma
            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            r = mclBnG1_setStr(&parameters->randomizers_sigma[it], pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }
            r = mclBnG1_isValid(&parameters->randomizers_sigma[it]);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }
        }
    }

    if (param_generate && pk_generate && sk_generate)
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Generating new ra_params.\n");
# endif

        /// chooses integers (k, j)
        parameters->k = REVOCATION_AUTHORITY_VALUE_K;
        parameters->j = REVOCATION_AUTHORITY_VALUE_J;

        // write integers (k, j)
        mem2hex(data, (const unsigned char *) &parameters->k, sizeof(uint32_t));
        data_length = 2 * sizeof(uint32_t);
        data[data_length] = '\n';
        data_length++;

        mem2hex(&data[data_length], (const unsigned char *) &parameters->j, sizeof(uint32_t));
        data_length += 2 * sizeof(uint32_t);
        data[data_length] = '\n';
        data_length++;

        /// chooses random integers (alphas)
        for (it = 0; it < parameters->j; it++)
        {
            // generate alphas
            mclBnFr_setByCSPRNG(&parameters->alphas[it]);
            r = mclBnFr_isValid(&parameters->alphas[it]);
            if (r != 1)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            // write alphas
            r = mclBnFr_getStr(&data[data_length], sizeof(data) - data_length, &parameters->alphas[it], 16);
            if (r == 0)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }
            data_length += r;
            data[data_length] = '\n';
            data_length++;

            // compute alphas mul
            mclBnG1_mul(&parameters->alphas_mul[it], &sys_parameters.G1, &parameters->alphas[it]);
            mclBnG1_normalize(&parameters->alphas_mul[it], &parameters->alphas_mul[it]);
            r = mclBnG1_isValid(&parameters->alphas_mul[it]);
            if (r != 1)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            // write alphas mul
            r = mclBnG1_getStr(&data[data_length], sizeof(data) - data_length, &parameters->alphas_mul[it], 16);
            if (r == 0)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }
            data_length += r;
            data[data_length] = '\n';
            data_length++;

            r = mclBnG1_getStr(&public_data[public_data_length], sizeof(public_data) - public_data_length, &parameters->alphas_mul[it], 16);
            if (r == 0)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }
            public_data_length +=  r;
            public_data[public_data_length] = '\n';
            public_data_length++;
        }

        /// chooses randomizers and signs each of them
        // set 1 to Fr data type
        mclBnFr_setInt32(&number_one, 1);

        for (it = 0; it < parameters->k; it++)
        {
            // choose randomizers
            mclBnFr_setByCSPRNG(&parameters->randomizers[it]);
            r = mclBnFr_isValid(&parameters->randomizers[it]);
            if (r != 1)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            // write randomizers
            r = mclBnFr_getStr(&data[data_length], sizeof(data) - data_length, &parameters->randomizers[it], 16);
            if (r == 0)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }
            data_length += r;
            data[data_length] = '\n';
            data_length++;

            // compute randomizers_sigma = (1 / (ez + sk)) * G1
            mclBnFr_add(&add_result, &parameters->randomizers[it], &keys->private_key.sk); // add_result = ez + sk
            mclBnFr_div(&div_result, &number_one, &add_result); // div_result = 1 / add_result
            mclBnG1_mul(&parameters->randomizers_sigma[it], &sys_parameters.G1, &div_result); // sigma = G1 * div_result
            mclBnG1_normalize(&parameters->randomizers_sigma[it], &parameters->randomizers_sigma[it]);
            r = mclBnG1_isValid(&parameters->randomizers_sigma[it]);
            if (r != 1)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }

            // write randomizers_sigma
            r = mclBnG1_getStr(&data[data_length], sizeof(data) - data_length, &parameters->randomizers_sigma[it], 16);
            if (r == 0)
            {
                fclose(ra_parameters_file);
                fclose(ra_public_parameters_file);
                return -1;
            }
            data_length += r;
            data[data_length] = '\n';
            data_length++;
        }
# ifndef NDEBUG
        fprintf(stdout, "[!] Writing RA parameters to file.\n");
# endif
        r = write_data_to_file(ra_parameters_file, data, data_length);
        if (r < data_length)
        {
            fprintf(stderr, "Error: writing data to ra_parameters.dat file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            return -1;
        }
# ifndef NDEBUG
        fprintf(stdout, "[!] Writing RA public parameters to file.\n");
# endif
        r = write_data_to_file(ra_public_parameters_file, public_data, public_data_length);
        if (r < public_data_length)
        {
            fprintf(stderr, "Error: writing data to ra_public_parameters.dat file!\n");
            fclose(ra_parameters_file);
            fclose(ra_public_parameters_file);
            return -1;
        }
    }
    else if (param_generate || pk_generate || sk_generate)
    {
        fprintf(stderr, "Error: invalid ra_parameters or ra_private_key or ra_public_key file!\n");
        fclose(ra_parameters_file);
        fclose(ra_public_parameters_file);
        return -1;
    }

    fclose(ra_parameters_file);
    fclose(ra_public_parameters_file);


# ifndef NDEBUG
    fprintf(stdout, "\n");
# endif
    return 0;
}

/**
 * Load the revocation authority parameters.
 *
 * @param parameters the revocation authority parameters
 * @param ra_parameters_file file with ra parameters. The file must be opened in mode "r+".
 *
 * @return 0 if success else -1
 */
int ra_get_parameters(revocation_authority_par_t *parameters, FILE *ra_parameters_file)
{
    char data[4096]= {0};
    char *pch;

    size_t it;
    int r;

    if (ra_parameters_file == NULL)
    {
        return -1;
    }

    if (parameters == NULL )
    {
        fclose(ra_parameters_file);
        return -1;
    }

    /// load ra parameters from file
    /*
     * File structure!
     * +---+---+---+---+---+---+---+---+
     * k
     * j
     * parameters->alphas[1]
     * parameters->alphas_mul[1]
     * ...
     * parameters->alphas[j]
     * parameters->alphas_mul[j]
     * parameters->randomizers[1]
     * parameters->randomizers_sigma[1]
     * ...
     * parameters->randomizers[k]
     * parameters->randomizers_sigma[k]
     * +---+---+---+---+---+---+---+---+
     *
     */
    r = read_data_from_file(ra_parameters_file,data, sizeof(data));
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid ra_parameters file!\n");
        fclose(ra_parameters_file);
        return -1;
    }
    else
    {
# ifndef NDEBUG
        fprintf(stdout, "[+] Reading ra_parameters from file.\n");
# endif

        // read integers (k, j)
        r = 0;
        pch = strtok(data, "\n");
        if (pch == NULL)
        {
            fprintf(stderr, "Error: invalid ra_parameters file!\n");
            fclose(ra_parameters_file);
            return -1;
        }
        hex2mem((unsigned char *) &parameters->k, pch, strlen(pch));
        if (parameters->k != REVOCATION_AUTHORITY_VALUE_K)
            r = -1;
        pch = strtok(NULL, "\n");
        hex2mem((unsigned char *) &parameters->j, pch, strlen(pch));
        if (parameters->j != REVOCATION_AUTHORITY_VALUE_J)
            r = -1;
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid ra_parameters file!\n");
            fclose(ra_parameters_file);
            return -1;
        }

        // read random integers (alphas)
        for (it = 0; it < parameters->j; it++)
        {
            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }

            r = mclBnFr_setStr(&parameters->alphas[it], (const char *) pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }

            r = mclBnFr_isValid(&parameters->alphas[it]);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }

            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }

            r = mclBnG1_setStr(&parameters->alphas_mul[it], pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }

            r = mclBnG1_isValid(&parameters->alphas_mul[it]);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }
        }

        // read randomizers and their signs
        for (it = 0; it < parameters->k; it++)
        {
            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }

            r = mclBnFr_setStr(&parameters->randomizers[it], (const char *) pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }
            r = mclBnFr_isValid(&parameters->randomizers[it]);
            if (r != 1)
            {
                fclose(ra_parameters_file);
                return -1;
            }

            // randomizers_sigma
            pch = strtok(NULL, "\n");
            if (pch == NULL)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }

            r = mclBnG1_setStr(&parameters->randomizers_sigma[it], pch, strlen(pch), 16);
            if (r < 0)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }
            r = mclBnG1_isValid(&parameters->randomizers_sigma[it]);
            if (r != 1)
            {
                fprintf(stderr, "Error: invalid ra_parameters file!\n");
                fclose(ra_parameters_file);
                return -1;
            }
        }
    }

    fclose(ra_parameters_file);
    return 0;
}

/**
 * Generate revocation handler.
 *
 * @param mr the revocation handler
 * @param ra_rh_file file with a revocation handlers. The file must be opened in mode "r".
 *
 * @return 0 if success else -1
 */
int ra_gen_rev_handler(mclBnFr *mr, FILE *ra_rh_file)
{
    char data[MAX_INPUT];

    int r;

    if (ra_rh_file == NULL)
    {
        return -1;
    }

    if (mr == NULL)
    {
        fclose(ra_rh_file);
        return -1;
    }

    do // generate unique random mr
    {
        mclBnFr_setByCSPRNG(mr);
        r = mclBnFr_isValid(mr);
        if (r != 1)
        {
            fclose(ra_rh_file);
            return -1;
        }

        r = mclBnFr_getStr(data, sizeof(data), mr, 16);
        if (r == 0)
        {
            fclose(ra_rh_file);
            return -1;
        }

        r = search_text_in_column(ra_rh_file, data, 2);
        if (r < 0)
        {
            fclose(ra_rh_file);
            return -1;
        }
    } while (r == 0);

    fclose(ra_rh_file);

    return 0;
}

/**
 * Computes the signature of the user identifier using the private key.
 *
 * @param sys_parameters the system parameters
 * @param private_key the revocation authority private key
 * @param ue_identifier the user identifier
 * @param signature the signature of the user identifier
 * @param ra_rh_file file with a revocation handlers. The file must be opened in mode "r".
 * @return 0 if success else -1
 */
int ra_mac(system_par_t sys_parameters, revocation_authority_private_key_t private_key, user_identifier_t ue_identifier, revocation_authority_signature_t *signature)
{
    mclBnFr number_one;
    mclBnFr add_result, div_result;

    unsigned char fr_data[EC_SIZE];
    mclBnFr fr_hash;

    char data[MAX_INPUT];

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    unsigned char hash[SHA_DIGEST_PADDING + SHA_DIGEST_LENGTH] = {0};
    SHA_CTX ctx;

    int r;
    size_t data_length;

    if (signature == NULL)
    {
        return -1;
    }

    // signature->mr to bytes
    mcl_Fr_to_bytes(fr_data, EC_SIZE, signature->mr);

    // H(mr || id)
    SHA1_Init(&ctx);
    SHA1_Update(&ctx, fr_data, EC_SIZE);
    SHA1_Update(&ctx, ue_identifier.buffer, ue_identifier.buffer_length);
    SHA1_Final(&hash[SHA_DIGEST_PADDING], &ctx);

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    mcl_bytes_to_Fr(&fr_hash, hash, EC_SIZE);
    r = mclBnFr_isValid(&fr_hash);
    if (r != 1)
    {
        return -1;
    }

    // set 1 to Fr data type
    mclBnFr_setInt32(&number_one, 1);

    // sigma = (1 / H(mr || id) + sk) * G1
    mclBnFr_add(&add_result, &fr_hash, &private_key.sk); // add_result = H(mr || id) + sk
    mclBnFr_div(&div_result, &number_one, &add_result); // div_result = 1 / add_result
    mclBnG1_mul(&signature->sigma, &sys_parameters.G1, &div_result); // sigma = G1 * div_result
    mclBnG1_normalize(&signature->sigma, &signature->sigma);
    r = mclBnG1_isValid(&signature->sigma);
    if (r != 1)
    {
        return -1;
    }

    return 0;
}

/**
 * Set user identifier and revocation handler to the revocation handler list.
 *
 * @param ue_identifier the user identifier
 * @param mr the revocation handler
 * @param ra_rh_file file with a revocation handlers. The file must be opened in mode "a+".
 * @return 0 if success else -1
 */
int ra_set_rev_handler(user_identifier_t ue_identifier, mclBnFr mr, FILE *ra_rh_file)
{
    char data[MAX_INPUT];

    size_t data_length;
    int r;

    if (ra_rh_file == NULL)
    {
        return -1;
    }

    mem2hex(data, ue_identifier.buffer, ue_identifier.buffer_length);
    data_length = strlen(data);
    strcat(data, ";");
    data_length++;

    r = mclBnFr_getStr(&data[data_length], sizeof(data) - ue_identifier.buffer_length, &mr, 16);
    if (r == 0)
    {
        fclose(ra_rh_file);
        return -1;
    }
    data_length += r;
    strcat(data, "\n");
    data_length++;

# ifndef NDEBUG
    fprintf(stdout, "[!] Writing revocation handler to file.\n");
# endif
    r = write_data_to_file(ra_rh_file, data, data_length);
    if (r < data_length)
    {
        fclose(ra_rh_file);
        return -1;
    }

    fclose(ra_rh_file);
    return 0;
}

/**
 * Load an epoch.
 *
 * @param epoch the epoch to be loaded
 * @param epoch_length the length of the epoch
 * @param epoch_file file where epoch is stored. The file should be opened in mode "r".
 *
 * @return 0 if success else -1
 */
int ra_get_epoch(void *epoch, size_t epoch_length, FILE *epoch_file)
{
    char str_epoch[2 * EPOCH_LENGTH];

    int r;

    if (epoch_file == NULL)
    {
        return -1;
    }

    if (epoch == NULL || epoch_length != EPOCH_LENGTH)
    {
        fclose(epoch_file);
        return -1;
    }

    // read epoch from the file
    r = read_data_from_file(epoch_file, str_epoch, sizeof(str_epoch));
    if (r != sizeof(str_epoch))
    {
        fprintf(stderr, "Error: invalid epoch file!\n");
        fclose(epoch_file);
        return -1;
    }

    hex2mem(epoch, str_epoch, epoch_length);

    fclose(epoch_file);
    return 0;
}

/**
 * Computes pseudonyms for epoch.
 *
 * @param epoch the epoch generated by the verifier
 * @param epoch_length the length of the epoch
 * @param ra_parameters the revocation authority parameters
 * @param ra_rh_file file with a revocation handlers. The file must be opened in mode "r".
 * @param dir path to work directory
 *
 * @return 0 if success else -1
 */
int ra_gen_pseudonyms_for_rhs(system_par_t sys_parameters, revocation_authority_par_t ra_parameters, const void *epoch, size_t epoch_length, FILE *ra_rh_file, char *dir)
{
    char data[4096] = {0};
    char file_name[MAX_INPUT] = {0};
    char dir_name[MAX_INPUT] = {0};
    char write_data[MAX_INPUT] = {0};
    char *pch;
    unsigned char hash[SHA_DIGEST_PADDING + SHA_DIGEST_LENGTH] = {0};

    FILE *epoch_rl;

    mclBnFr m_r, fr_hash, mul_result;
    mclBnFr i[REVOCATION_AUTHORITY_VALUE_K_J];

    mclBnG1 pseudonym;

    // used to obtain the point data independently of the platform
    char digest_platform_point[192] = {0};

    size_t it = 0, it_I, it_II;
    int r;


    if (ra_rh_file == NULL)
    {
        return -1;
    }

    if (epoch == NULL || epoch_length <= 0)
    {
        fclose(ra_rh_file);
        return -1;
    }


    // compute array of i value
    for (it_I = 0; it_I < (REVOCATION_AUTHORITY_VALUE_K); it_I++)
    {
        for (it_II = 0; it_II < (REVOCATION_AUTHORITY_VALUE_K); it_II++)
        {
            mclBnFr_mul(&i[it], &ra_parameters.alphas[0], &ra_parameters.randomizers[it_I]);
            mclBnFr_mul(&mul_result, &ra_parameters.alphas[1], &ra_parameters.randomizers[it_II]);
            mclBnFr_add(&i[it], &i[it], &mul_result);
            it++;
        }
    }

    // compute H(epoch)
    SHA1(epoch, epoch_length, &hash[SHA_DIGEST_PADDING]);

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    mcl_bytes_to_Fr(&fr_hash, hash, EC_SIZE);
    r = mclBnFr_isValid(&fr_hash);
    if (r != 1)
    {
        fclose(ra_rh_file);
        return -1;
    }

    // make epoch directory
    strcpy(dir_name, dir);
    strcat(dir_name, "epoch_");
    mem2hex(&dir_name[strlen(dir_name)], epoch, epoch_length);
    if (!is_dir_exists(dir_name))
    {
        r = mkdir(dir_name, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        if (r != 0)
        {
            fprintf(stderr, "Error: cannot create %s directory!\n", dir_name);
            fclose(ra_rh_file);
            return -1;
        }
    }

    while(fgets(data, sizeof(data), ra_rh_file) != NULL)
    {
        // parse data
        pch = strtok(data, ";");
        pch = strtok(NULL, "\n");

        if (pch == NULL)
        {
            fprintf(stderr, "Error: invalid revocation handlers file!");
            fclose(ra_rh_file);
            return -1;
        }

        // create file
        strcpy(file_name, dir_name);
        strcat(file_name, "/");
        strcat(file_name, pch);
        strcat(file_name, "_");
        mem2hex(&file_name[strlen(file_name)], epoch, epoch_length);
        strcat(file_name, ".csv");

        epoch_rl = fopen(file_name, "w");
        if (epoch_rl == NULL)
        {
            fclose(ra_rh_file);
            return -1;
        }

        // convert m_r to mclBnFr
        mclBnFr_clear(&m_r);
        mclBnFr_setStr(&m_r, (const char *) pch, strlen(pch), 16);
        if (r < 0)
        {
            fprintf(stderr, "Error: invalid revocation handler detected!\n");
            fclose(ra_rh_file);
            fclose(epoch_rl);
            return -1;
        }

        r = mclBnFr_isValid(&m_r);
        if (r != 1)
        {
            fprintf(stderr, "Error: invalid revocation handler detected!\n");
            fclose(ra_rh_file);
            fclose(epoch_rl);
            return -1;
        }

        // compute -m_r
        mclBnFr_neg(&m_r, &m_r);

        // compute C[it] and write it
        for (it = 0; it < REVOCATION_AUTHORITY_VALUE_K_J; it++)
        {
            mclBnFr_add(&mul_result, &i[it], &m_r); // mul_result = i_ptr[it] - m_r
            mclBnFr_add(&mul_result, &mul_result, &fr_hash); // i_ptr[it] = i_ptr[it] - m_r + H(epoch)
            mclBnFr_inv(&mul_result, &mul_result); // i_ptr[it] = 1 /  i_ptr[it] - m_r + H(epoch)

            mclBnG1_mul(&pseudonym, &sys_parameters.G1, &mul_result); // C = G1·i
            mclBnG1_normalize(&pseudonym, &pseudonym);
            r = mclBnG1_isValid(&pseudonym);
            if (r != 1)
            {
                fclose(ra_rh_file);
                fclose(epoch_rl);
                fprintf(stderr, "Error: invalid pseudonym computed!\n");
                return -1;
            }

            SHA256(digest_get_platform_point_data(digest_platform_point, pseudonym), digest_get_platform_point_size(), hash); // H(C)

            mem2hex(write_data, hash, SHA256_DIGEST_LENGTH);
            strcat(write_data, "\n");

            r = write_data_to_file(epoch_rl, write_data, strlen(write_data));
            if (r != strlen(write_data))
            {
                fclose(ra_rh_file);
                fclose(epoch_rl);
                return -1;
            }
        }
        fclose(epoch_rl);
    }
    if (!feof(ra_rh_file))
    {
        return -1;
    }

    fclose(ra_rh_file);
    return 0;
}

/**
 * Computes pseudonyms for epoch.
 *
 * @param epoch the epoch generated by the verifier
 * @param epoch_length the length of the epoch
 * @param ra_parameters the revocation authority parameters
 * @param m_r
 * @param dir path to work directory
 *
 * @return 0 if success else -1
 */
int ra_gen_pseudonyms_for_rh(system_par_t sys_parameters, revocation_authority_par_t ra_parameters, const void *epoch, size_t epoch_length,  mclBnFr m_r, char *dir)
{
    char file_name[MAX_INPUT] = {0};
    char dir_name[MAX_INPUT] = {0};
    char write_data[MAX_INPUT] = {0};
    char str_mr[MAX_INPUT] = {0};

    unsigned char hash[SHA_DIGEST_PADDING + SHA_DIGEST_LENGTH] = {0};

    FILE *epoch_rl;

    mclBnFr fr_hash, mul_result;
    mclBnFr i[REVOCATION_AUTHORITY_VALUE_K_J];

    mclBnG1 pseudonym;

    // used to obtain the point data independently of the platform
    char digest_platform_point[192] = {0};

    size_t it = 0, it_I, it_II;
    int r;


     if (epoch == NULL || epoch_length <= 0 || dir == NULL)
    {
        return -1;
    }


    // compute array of i value
    for (it_I = 0; it_I < (REVOCATION_AUTHORITY_VALUE_K); it_I++)
    {
        for (it_II = 0; it_II < (REVOCATION_AUTHORITY_VALUE_K); it_II++)
        {
            mclBnFr_mul(&i[it], &ra_parameters.alphas[0], &ra_parameters.randomizers[it_I]);
            mclBnFr_mul(&mul_result, &ra_parameters.alphas[1], &ra_parameters.randomizers[it_II]);
            mclBnFr_add(&i[it], &i[it], &mul_result);
            it++;
        }
    }

    // compute H(epoch)
    SHA1(epoch, epoch_length, &hash[SHA_DIGEST_PADDING]);

    /*
     * IMPORTANT!
     *
     * We are using SHA1 on the Smart Card. However, because the length
     * of the SHA1 hash is 20 and the size of Fr is 32, it is necessary
     * to enlarge 12 characters and fill them with 0's.
     */
    mcl_bytes_to_Fr(&fr_hash, hash, EC_SIZE);
    r = mclBnFr_isValid(&fr_hash);
    if (r != 1)
    {
        return -1;
    }

    // convert mclBnFr m_r to string
    mclBnFr_getStr(str_mr, sizeof(str_mr), &m_r, 16);
    if (r == 0)
    {
        fprintf(stderr, "Error: invalid revocation handler detected!\n");
        return -1;
    }

    // make epoch directory
    strcpy(dir_name, dir);
    strcat(dir_name, "epoch_");
    mem2hex(&dir_name[strlen(dir_name)], epoch, epoch_length);
    if (!is_dir_exists(dir_name))
    {
        fprintf(stderr, "Error: directory %s does not exist!\n", dir_name);
        return -1;
    }

    // create file
    file_name[0] = '\0';

    strcat(file_name, dir_name);
    strcat(file_name, "/");
    strcat(file_name, str_mr);
    strcat(file_name, "_");
    mem2hex(&file_name[strlen(file_name)], epoch, epoch_length);
    strcat(file_name, ".csv");

    epoch_rl = fopen(file_name, "w");
    if (epoch_rl == NULL)
    {
        fprintf(stderr, "Error: cannot open file %s\n", file_name);
        return -1;
    }

    // compute -m_r
    mclBnFr_neg(&m_r, &m_r);

    // compute C[it] and write it
    for (it = 0; it < REVOCATION_AUTHORITY_VALUE_K_J; it++)
    {
        mclBnFr_add(&i[it], &i[it], &m_r); // i_ptr[it] = i_ptr[it] - m_r
        mclBnFr_add(&i[it], &i[it], &fr_hash); // i_ptr[it] = i_ptr[it] - m_r + H(epoch)
        mclBnFr_inv(&i[it], &i[it]); // i_ptr[it] = 1 /  i_ptr[it] - m_r + H(epoch)

        mclBnG1_mul(&pseudonym, &sys_parameters.G1, &i[it]); // C = G1·i

        SHA256(digest_get_platform_point_data(digest_platform_point, pseudonym), digest_get_platform_point_size(), hash); // H(C)

        mem2hex(write_data, hash, SHA256_DIGEST_LENGTH);
        strcat(write_data, "\n");

        r = write_data_to_file(epoch_rl, write_data, strlen(write_data));
        if (r != strlen(write_data))
        {
            fclose(epoch_rl);
            return -1;
        }
    }
    fclose(epoch_rl);


    return 0;
}

/**
 * Create revoke database for epoch
 *
 * @param epoch the epoch generated by the verifier
 * @param epoch_length the length of the epoch
 * @param path path to work directory
 *
 * @return 0 if success else -1
 */
int ra_gen_rd_for_epoch(const void *epoch, size_t epoch_length, char *path)
{
    DIR * d;
    struct dirent * dir; // for the directory entries

    char file_name[PATH_MAX] = {0};
    char dir_name[PATH_MAX] = {0};

    char data[4096];
    char *pch;

    FILE *epoch_rd;
    FILE *tmp_file;

    size_t data_length;
    int r;

    if (epoch == NULL || epoch_length <= 0 || path == NULL)
    {
        return -1;
    }

    // create rd_epoch file
    strcat(file_name, path);
    strcat(file_name, "rd_");
    mem2hex(&file_name[strlen(file_name)], epoch, epoch_length);
    strcat(file_name, ".csv");

    epoch_rd = fopen(file_name, "w");
    if (epoch_rd == NULL)
    {
        return -1;
    }

    // open rhs directory
    strcat(dir_name, path);
    strcat(dir_name, "epoch_");
    mem2hex(&dir_name[strlen(dir_name)], epoch, epoch_length);

    d = opendir(dir_name); // open the path
    if(d == NULL)
    {
        return -1; // if was not able return
    }

    // copy files to rd_epoch
    while ((dir = readdir(d)) != NULL) // if we were able to read something from the directory
    {
        if(dir-> d_type != DT_DIR) // if the type is not directory
        {
            file_name[0] = '\0';
            strcat(file_name, dir_name);
            strcat(file_name, "/");
            strcat(file_name, dir->d_name);

            // open handlers file
            tmp_file = fopen(file_name, "r");
            if (tmp_file == NULL)
            {
                fclose(epoch_rd);
                return -1;
            }

            // get m_r from file name
            pch = strtok(dir->d_name, "_");
            strcpy(data, pch);
            strcat(data, ";");
            data_length = strlen(data);

            // copy content to rd file
            while (fgets(&data[data_length], (int) (sizeof(data) - data_length), tmp_file) != NULL)
            {
                r = write_data_to_file(epoch_rd, data, strlen(data));
                if (r != strlen(data))
                {
                    fclose(epoch_rd);
                    fclose(tmp_file);
                    return -1;
                }
            }
            fclose(tmp_file);
        }
    }
    closedir(d); // finally close the directory
    fclose(epoch_rd);
    return 0;
}

/**
 * Update revoke database for epoch
 *
 * @param epoch the epoch generated by the verifier
 * @param epoch_length the length of the epoch
 * @param m_r
 * @param path path to work directory
 *
 * @return 0 if success else -1
 */
int ra_update_rd_for_epoch(const void *epoch, size_t epoch_length, mclBnFr m_r, char *path)
{
    char file_name[PATH_MAX] = {0};
    char dir_name[PATH_MAX] = {0};
    char str_mr[MAX_INPUT] = {0};

    char data[4096];

    FILE *epoch_rd;
    FILE *tmp_file;

    int r;
    size_t data_length;

    if (epoch == NULL || epoch_length <= 0 || path == NULL)
    {
        return -1;
    }

    // open rd_epoch file
    strcat(file_name, path);
    strcat(file_name, "rd_");
    mem2hex(&file_name[strlen(file_name)], epoch, epoch_length);
    strcat(file_name, ".csv");

    epoch_rd = fopen(file_name, "a");
    if (epoch_rd == NULL)
    {
        return -1;
    }

    // convert mclBnFr m_r to string
    r = mclBnFr_getStr(str_mr, sizeof(str_mr), &m_r, 16);
    if (r == 0)
    {
        fprintf(stderr, "Error: invalid revocation handler detected!\n");
        fclose(epoch_rd);
        return -1;
    }

    // open pseudonyms directory
    strcat(dir_name, path);
    strcat(dir_name, "epoch_");
    mem2hex(&dir_name[strlen(dir_name)], epoch, epoch_length);

    // open pseudonyms file
    file_name[0] = '\0';
    strcat(file_name, dir_name);
    strcat(file_name, "/");
    strcat(file_name, str_mr);
    strcat(file_name, "_");
    mem2hex(&file_name[strlen(file_name)], epoch, epoch_length);
    strcat(file_name, ".csv");

    tmp_file = fopen(file_name, "r");
    if (tmp_file == NULL)
    {
        fclose(epoch_rd);
        return -1;
    }

    // set m_r to data
    strcpy(data, str_mr);
    strcat(data, ";");
    data_length = strlen(data);

    // copy content to rd file
    while (fgets(&data[data_length], (int) (sizeof(data) - data_length), tmp_file) != NULL)
    {
        r = write_data_to_file(epoch_rd, data, strlen(data));
        if (r != strlen(data))
        {
            fclose(epoch_rd);
            fclose(tmp_file);
            return -1;
        }
    }
    fclose(tmp_file);
    fclose(epoch_rd);

    return 0;
}

/**
 * Revoke user.
 *
 * @param m_r
 * @param ra_rm_revoke file
 *
 * @return 0 if success else -1
 */
int ra_revoke_user_rh(mclBnFr m_r, FILE *ra_rm_revoke)
{
    char str_m_r[MAX_INPUT];

    int r;

    if (ra_rm_revoke == NULL)
    {
        fprintf(stderr, "Error: Invalid argument ra_rm_revoke file!\n");
        return -1;
    }

    // get m_r string
    r = mclBnFr_getStr(str_m_r, sizeof(str_m_r) , &m_r, 16);
    if (r == 0)
    {
        fclose(ra_rm_revoke);
        fprintf(stderr, "Error: Invalid m_r!\n");
        return -1;
    }
    strcat(str_m_r, "\n");

    r = write_data_to_file(ra_rm_revoke, str_m_r, strlen(str_m_r));
    if (r != strlen(str_m_r))
    {
        fprintf(stderr, "Error: Cannot write data to ra_rm_revoke file!\n");
        fclose(ra_rm_revoke);
        return -1;
    }

    fclose(ra_rm_revoke);
    return 0;
}

/**
 * Create revocation list (black list) for epoch and C
 *
 * @param m_r the revocation handler
 * @param pseudonym_and_epoch the epoch set by the verifier
 * @param epoch_length the length of the epoch
 * @param path path to work directory
 *
 * @return 0 if success else -1
 */
int ra_revokeC(mclBnFr *m_r, char *pseudonym_and_epoch, size_t epoch_length, char *path)
{
    char data[MAX_INPUT] = {0};
    char file_name[PATH_MAX] = {0};
    char *pch;

    FILE *epoch_rd;
    FILE *epoch_black_list;
    FILE *epoch_pseudonyms;

    char str_pseudonym[MAX_INPUT];
    char str_m_r[MAX_INPUT];
    char str_epoch[2 * EPOCH_LENGTH + 1];

    int r;


    if (pseudonym_and_epoch == NULL || epoch_length <= 0 || path == NULL)
    {
        return -1;
    }

    // get epoch from string
    pch = strtok(pseudonym_and_epoch, " \t");
    if (pch == NULL)
    {
        fprintf(stderr, "Error: Invalid argument %s!\n", pseudonym_and_epoch);
        return -1;
    }
    strcpy(str_epoch, pch);

    // get epoch and pseudonym from string
    pch = strtok(NULL, "\0");
    if (pch == NULL)
    {
        fprintf(stderr, "Error: Invalid argument %s!\n", pseudonym_and_epoch);
        return -1;
    }
    strcpy(str_pseudonym, pch);

    // open revocation database
# ifndef NDEBUG
    fprintf(stdout, "[+] Opening the revocation database.\n");
# endif
    strcat(file_name, path);
    strcat(file_name, "rd_");
    strcat(file_name, str_epoch);
    strcat(file_name, ".csv");

    epoch_rd = fopen(file_name, "r");
    if (epoch_rd == NULL)
    {
        fprintf(stderr, "Error: Revocation database %s does not exist! Initialize this epoch (-r -e)\n", file_name);
        return -1;
    }

    // find mr
# ifndef NDEBUG
    fprintf(stdout, "[+] Revocation handler searching.\n");
# endif

    r = vertical_lookup(epoch_rd, str_pseudonym, str_m_r, 1);
    if (r != 0)
    {
        fclose(epoch_rd);
        fprintf(stderr, "Error: Given pseudonym hash was not found in revocation database %s\n", file_name);
        return -1;
    }
    fclose(epoch_rd);

    // convert m_r to mclBnFr
    mclBnFr_setStr(m_r, str_m_r, strlen(str_m_r), 16);
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid revocation handler detected!\n");
        return -1;
    }

    r = mclBnFr_isValid(m_r);
    if (r != 1)
    {
        fprintf(stderr, "Error: invalid revocation handler detected!\n");
        return -1;
    }

    // open black list
    strcpy(file_name, path);
    strcat(file_name, "ra_BL_epoch_");
    strcat(file_name, str_epoch);
    strcat(file_name, "_C_for_verifier.dat");

    epoch_black_list = fopen(file_name, "w");
    if (epoch_black_list == NULL)
    {
        fprintf(stderr, "Error: cannot open %s!\n", file_name);
        return -1;
    }

    // open epoch directory
    strcpy(file_name, path);
    strcat(file_name, "epoch_");
    strcat(file_name, str_epoch);
    strcat(file_name, "/");
    if (!is_dir_exists(file_name))
    {
        fprintf(stderr, "Error: epoch directory %s does not exist!\n", file_name);
        fclose(epoch_black_list);
        return -1;
    }

    // find the appropriate m_r file
    strcat(file_name, str_m_r);
    strcat(file_name, "_");
    strcat(file_name, str_epoch);
    strcat(file_name, ".csv");

    epoch_pseudonyms = fopen(file_name, "r");
    if (epoch_pseudonyms == NULL)
    {
        fprintf(stderr, "Error: cannot open %s!\n", file_name);
        return -1;
    }

    // copy content to blacklist
    while (fgets(data, sizeof(data) , epoch_pseudonyms) != NULL)
    {
        r = write_data_to_file(epoch_black_list, data, strlen(data));
        if (r != strlen(data))
        {
            fprintf(stderr, "Error: cannot copy pseudonyms from %s!\n", file_name);
            fclose(epoch_pseudonyms);
            fclose(epoch_black_list);
            return -1;
        }
    }

    fclose(epoch_black_list);
    fclose(epoch_pseudonyms);

    return 0;
}

/**
 * Create revocation list (black list) for epoch and id
 *
 * @param m_r the revocation handler
 * @param id_and_epoch the epoch set by the verifier
 * @param epoch_length the length of the epoch
 * @param ra_rh_file file with a revocation handlers. The file must be opened in mode "r".
 * @param path path to work directory
 *
 * @return 0 if success else -1
 */
int ra_revokeID(mclBnFr *m_r, char *id_and_epoch, size_t epoch_length, FILE * ra_rh_file, char *path)
{
    char data[MAX_INPUT] = {0};
    char file_name[PATH_MAX] = {0};
    char *pch;

    FILE *epoch_black_list;
    FILE *epoch_pseudonyms;

    char str_id[MAX_INPUT];
    char str_m_r[MAX_INPUT];
    char str_epoch[MAX_INPUT];

    int r;

    if (ra_rh_file == NULL)
    {
        return -1;
    }

    if (id_and_epoch == NULL || epoch_length <= 0 || path == NULL)
    {
        fclose(ra_rh_file);
        return -1;
    }

    // get epoch from string
    pch = strtok(id_and_epoch, " \t");
    if (pch == NULL)
    {
        fprintf(stderr, "Error: Invalid argument %s!\n", id_and_epoch);
        fclose(ra_rh_file);
        return -1;
    }
    strcpy(str_epoch, pch);

    // get id from string
    pch = strtok(NULL, "\0");
    if (pch == NULL)
    {
        fprintf(stderr, "Error: Invalid argument %s!\n", id_and_epoch);
        fclose(ra_rh_file);
        return -1;
    }
    strcpy(str_id, pch);

    // find mr
# ifndef NDEBUG
    fprintf(stdout, "[+] Revocation handler searching.\n");
# endif

    r = vertical_lookup(ra_rh_file, str_id, str_m_r, 2);
    if (r != 0)
    {
        fclose(ra_rh_file);
        fprintf(stderr, "Error: Given id was not found in revocation handler list %s\n", file_name);
        return -1;
    }
    fclose(ra_rh_file);

    // convert m_r to mclBnFr
    mclBnFr_setStr(m_r, str_m_r, strlen(str_m_r), 16);
    if (r < 0)
    {
        fprintf(stderr, "Error: invalid revocation handler detected!\n");
        return -1;
    }

    r = mclBnFr_isValid(m_r);
    if (r != 1)
    {
        fprintf(stderr, "Error: invalid revocation handler detected!\n");
        return -1;
    }

    // open black list
    strcpy(file_name, path);
    strcat(file_name, "ra_BL_epoch_");
    strcat(file_name, str_epoch);
    strcat(file_name, "_C_for_verifier.dat");

    epoch_black_list = fopen(file_name, "w");
    if (epoch_black_list == NULL)
    {
        fprintf(stderr, "Error: cannot open %s!\n", file_name);
        return -1;
    }

    // open epoch directory
    strcpy(file_name, path);
    strcat(file_name, "epoch_");
    strcat(file_name, str_epoch);
    strcat(file_name, "/");
    if (!is_dir_exists(file_name))
    {
        fprintf(stderr, "Error: epoch directory %s does not exist!\n", file_name);
        fclose(epoch_black_list);
        return -1;
    }

    // find the appropriate m_r file
    strcat(file_name, str_m_r);
    strcat(file_name, "_");
    strcat(file_name, str_epoch);
    strcat(file_name, ".csv");

    epoch_pseudonyms = fopen(file_name, "r");
    if (epoch_pseudonyms == NULL)
    {
        fprintf(stderr, "Error: cannot open %s!\n", file_name);
        return -1;
    }

    // copy content to blacklist
    while (fgets(data, sizeof(data) , epoch_pseudonyms) != NULL)
    {
        r = write_data_to_file(epoch_black_list, data, strlen(data));
        if (r != strlen(data))
        {
            fprintf(stderr, "Error: cannot copy pseudonyms from %s!\n", file_name);
            fclose(epoch_pseudonyms);
            fclose(epoch_black_list);
            return -1;
        }
    }

    fclose(epoch_black_list);
    fclose(epoch_pseudonyms);

    return 0;
}

/**
 * Generate blacklist for new epoch from revoked users file
 *
 * @param id_and_epoch the epoch set by the verifier
 * @param epoch_length the length of the epoch
 * @param ra_rm_revoke file
 * @param path path to work directory
 *
 * @return 0 if success else -1
 */
int ra_gen_bl_for_epoch(const void *epoch, size_t epoch_length, FILE *ra_rm_revoke, char *path)
{
    char file_name[PATH_MAX] = {0};
    char dir_name[PATH_MAX] = {0};

    char str_epoch[MAX_INPUT];

    char data[4096];
    char *pch;

    FILE *tmp_file;
    FILE *epoch_black_list;

    int r;

    if (ra_rm_revoke == NULL)
    {
        return -1;
    }

    if (epoch == NULL || epoch_length <= 0 || path == NULL)
    {
        fclose(ra_rm_revoke);
        return -1;
    }

    // set epoch to string
    mem2hex(str_epoch, epoch, epoch_length);

    // open black list
    strcpy(file_name, path);
    strcat(file_name, "ra_BL_epoch_");
    strcat(file_name, str_epoch);
    strcat(file_name, "_C_for_verifier.dat");

    epoch_black_list = fopen(file_name, "w");
    if (epoch_black_list == NULL)
    {
        fprintf(stderr, "Error: cannot open %s!\n", file_name);
        return -1;
    }

    // open epoch directory
    strcpy(dir_name, path);
    strcat(dir_name, "epoch_");
    strcat(dir_name, str_epoch);
    strcat(dir_name, "/");
    if (!is_dir_exists(dir_name))
    {
        fprintf(stderr, "Error: epoch directory %s does not exist!\n", dir_name);
        fclose(ra_rm_revoke);
        fclose(epoch_black_list);
        return -1;
    }

    while(fgets(data, sizeof(data), ra_rm_revoke) != NULL)
    {
        // parse data
        pch = strtok(data, "\n");

        if (pch == NULL)
        {
            fprintf(stderr, "Error: invalid revoked users file!");
            fclose(ra_rm_revoke);
            fclose(epoch_black_list);
            return -1;
        }

        // find the appropriate m_r file
        strcpy(file_name, dir_name);
        strcat(file_name, pch);
        strcat(file_name, "_");
        strcat(file_name, str_epoch);
        strcat(file_name, ".csv");

        tmp_file = fopen(file_name, "r");
        if (tmp_file == NULL)
        {
            fprintf(stderr, "Error: cannot open %s!\n", file_name);
            fclose(ra_rm_revoke);
            fclose(epoch_black_list);
            return -1;
        }

        // copy content to blacklist
        while (fgets(data, sizeof(data) , tmp_file) != NULL)
        {
            r = write_data_to_file(epoch_black_list, data, strlen(data));
            if (r != strlen(data))
            {
                fprintf(stderr, "Error: cannot copy pseudonyms from %s!\n", file_name);
                fclose(ra_rm_revoke);
                fclose(tmp_file);
                fclose(epoch_black_list);
                return -1;
            }
        }
        fclose(tmp_file);
    }
    fclose(epoch_black_list);
    fclose(ra_rm_revoke);

    return 0;
}
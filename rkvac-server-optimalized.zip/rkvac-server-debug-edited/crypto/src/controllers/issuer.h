/**
 *
 *  Copyright (C) 2020  Raul Casanova Marques
 *  Copyright (C) 2020  Michal Moravanský
 *
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef __RKVAC_PROTOCOL_CONTROLLER_ISSUER_H_
#define __RKVAC_PROTOCOL_CONTROLLER_ISSUER_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stddef.h>
#include <string.h>
#include <assert.h>

#include <mcl/bn_c256.h>
#include <openssl/sha.h>

#include "crypto/config/config.h"

#include "crypto/include/models/issuer.h"
#include "crypto/include/models/revocation-authority.h"
#include "crypto/include/models/user.h"
#include "crypto/include/system.h"

#include "crypto/helpers/mcl_helper.h"
#include "crypto/helpers/file_helper.h"

#include "issuer.h"

/**
* Get the user attributes from file.
*
* @param credentials the Issuer credentials
* @param ue_attributes the user attributes
* @param ie_user_attributes_file file with the user attributes. The file should be opened in mode "r".
*
* @return 0 if success else -1
*/
extern int ie_get_user_attributes(ie_credentials_t *credentials, user_attributes_t *ue_attributes, FILE *ie_user_attributes_file);

/**
 * Read or compute the issuer parameters, generates or load the private keys, load RA public key.
 *
 * @param parameters the issuer parameters
 * @param ie_private_keys the issuer private keys
 * @param ra_public_key the revocation authority public key.
 * @param ie_private_keys_file file with private keys x(0),x(1)...x(n-1).
 * @param ra_public_key_file file with ra public key. The file should be opened in mode "r".
 *
 * @return 0 if success else -1
 */
extern int ie_setup(issuer_par_t parameters, issuer_keys_t *ie_private_keys, revocation_authority_public_key_t *ra_public_key, FILE *ie_private_keys_file, FILE *ra_public_key_file);

/**
 * Outputs the user identifier.
 *
 * @param identifier the user identifier
 * @param user_list the user list file
 * @return 0 if success else -1
 */
extern int ie_generate_user_identifier(user_identifier_t *identifier, FILE *user_list);

/**
 * Set the user identifier to the user list file.
 *
 * @param identifier the user identifier
 * @param user_list the user list file
 * @param ue_name user name
 * @param ue_surname user surname
 *
 * @return 0 if success else -1
 */
extern int ie_set_user_identifier(user_identifier_t *identifier, FILE *user_list, char *ue_name, char *ue_surname);

/**
 * Get the user name and surname from the user list file.
 *
 * @param identifier the user identifier
 * @param user_list the user list file
 * @param ue_name user name
 * @param ue_surname user surname
 *
 * @return 0 if success else -1
 */
extern int ie_get_user_full_name(user_identifier_t identifier, FILE *user_list, char *ue_name, char *ue_surname);

/**
 * Outputs the SHA256(user attribute).
 *
 * @param credentials issuer credentials
 *
 * @return 0 if success else -1
 */
extern int ie_generate_user_attribute(ie_attribute_str_value_t str_credentials, uint8_t *attribute_value);

/**
 * Set the user attributes to file.
 *
 * @param credentials issuer credentials
 * @param ue_attributes the user attributes
 * @param ie_user_attributes_file empty file to write user attributes. The file must be opened in mode "w".
 *
 * @return 0 if success else -1
 */
extern int ie_set_user_attributes(ie_credentials_t credentials, user_attributes_t ue_attributes,FILE *ie_user_attributes_file);

/**
 * Computes the signature of the user attributes using the private keys.
 *
 * @param sys_parameters the system parameters
 * @param parameters the issuer parameters
 * @param keys the issuer keys
 * @param ra_public_key the revocation authority public key.
 * @param ue_identifier the user identifier
 * @param ue_attributes the user attributes
 * @param revocation_authority_signature the revocation authority signature (mr, ra_sigma)
 * @param signature the signature of the user attributes
 *
 * @return 0 if success else -1
 */
extern int ie_issue(system_par_t sys_parameters, issuer_par_t parameters, issuer_keys_t keys, revocation_authority_public_key_t ra_public_key, user_identifier_t ue_identifier, user_attributes_t ue_attributes,
             revocation_authority_signature_t revocation_authority_signature, issuer_signature_t *signature);

#ifdef __cplusplus
}
#endif

#endif /* __RKVAC_PROTOCOL_CONTROLLER_ISSUER_H_ */

# rkvac-protocol-multos-1.0.0
This is a C implementation of the RKVAC (_Revocable Keyed-Verification Anonymous Credentials_) protocol.

## Table of Contents
- [Getting started](#getting-started)
    - [Dependencies](#dependencies)
- [Usage](#usage)
    - [Command line options](#command-line-options)
- [Build instructions](#build-instructions)
    - [Generic build options](#generic-build-options)
    - [MULTOS build options](#multos-build-options)
- [Install dependencies](#install-dependencies)
    - [Install dependencies using the package manager](#install-dependencies-using-the-package-manager)
    - [Install dependencies from source](#install-dependencies-from-source)
- [Benchmarks](#benchmarks)
- [Project structure](#project-structure)
    - [Source tree](#source-tree)
    - [Source description](#source-description)
- [License](#license)

## Getting started
These instructions will get you a copy of the project up and running on your local machine for development
and testing purposes.

### Dependencies
The following table summarizes the tools and libraries required to build. By default,
the build uses the library installed on the system. However, if no library is found
installed on the system, you have to specify the path where the necessary libraries
are installed.

| Dependency   | Tested version  | Debian/Ubuntu pkg    | Optional | Purpose         |
| ------------ | --------------- | -------------------- | -------- | --------------- |
| CMake        | 3.17            | `cmake`              | NO       | -               |
| Zlib         | 1.2.11          | `zlib1g-dev`         | NO       | For OpenSSL     |
| OpenSSL      | 1.1.1g          | `libssl-dev`         | NO       | For MCL library |
| GMP          | 6.2.0           | `libgmp-dev`         | NO       | For MCL library |
| MCL          | 1.11            | `-`                  | NO       | Cryptography    |
| PCSC         | 1.8.24          | `libpcsclite-dev`    | NO       | SmartCard PC/SC |
| PCSCD        | 1.8.24          | `pcscd`              | NO       | SmartCard PC/SC |

## Usage
1. Open a terminal within the folder with the executable
2. Start with `./rkvac-protocol-multos-1.0.0 --selected_entity [--possible_options_for_entity=${xx}]`

### Command line options
It is allowed to overwrite some of the settings via command line options.
Run `rkvac-protocol --help` to show all available command line options.

| Short option           | Long option                       | Argument      | Description                                                                                                                       |
|------------------------|-----------------------------------|---------------|---------------------------------------------------------------------------------------------------------------------------------- |
| `-p`                   | `--personalization`               | no            | create or update the User list file, generate user identifier and set it to the card.                                             |
| `[-n ${name}]`         | `--user-name=${name}`             | required      | the user name used for card personalization.                                                                                      | 
| `[-s ${surname}]`      | `--user-surname=${surname}`       | required      | the user surname used for card personalization.                                                                                   |
| `-r`                   | `--revocation-authority`          | no            | check or create Revocation Authority files, revocation handlers file. Set revocation handler and RA parameters to the card.       |
| `[-e${filename}]`      | `--new-epoch=${filename}`         | optional      | generate revocation database and blacklist for new epoch.                                                                         |
| `[-b ${"epoch H(C)}"]` | `--revoke-user-c=${"epoch H(C)"}` | required      | create blacklist for given epoch and pseudonym hash (whitespace separated).                                                       |
| `[-B ${"epoch ID}"]`   | `--revoke-user-id=${"epoch ID"}`  | required      | create blacklist for given epoch and user id (whitespace separated).                                                              |
| `-i`                   | `--issuer`                        | no            | check or create Issuer private keys file. Load RA public key file. Set user attributes and their signatures to the card.          |
| `[-a ${filename}]`     | `--set-attributes=${filename}`    | required      | obligatory option for Issuer. Load user attributes from defined file (or create file if it does not exist) and set it to the card.|
| `-v`                   | `--verifier`                      | no            | load user attributes file, RA public parameters file, RA public key file, IE private keys file. Verify proof of knowledge.        |
| `[-a ${filename}]`     | `--set-attributes=${filename}`    | optional      | load user attributes from defined file (or create file if it does not exist).                                                     |
| `[-e${filename}]`      | `--new-epoch=${filename}`         | optional      | generate new epoch (ccDDMMYY, cc = counter 1..256).                                                                               |
| `[-u ${filename}]`     | `--update-bl=${filename}`         | required      | update blacklist.                                                                                                                 |
| `[-w ${filename}]`     | `--rewrite-bl=${filename}`        | required      | rewrite blacklist.                                                                                                                |
| `[-c ${filename}]`     | `--create-credentials=${filename}`| required      | save user attributes to the defined file (create or rewrite file).                                                                |
| `-h`                   | `--help`                          | no            | shows this help                                                                                                                   |

## Build instructions
x86-64/ARM/ARM64 Linux and macOS are supported. If you have any problems during compilation,
please check the [Install dependencies](#install-dependencies) section.

### Generic build options
- **Note**: this will produce the following executable: `rkvac-protocol-multos-1.0.0`

- `OPENSSL_ROOT_DIR` specify where the OpenSSL library is located
    - `cmake .. -DOPENSSL_ROOT_DIR=${openssl-dir}`
- `MCL_ROOT_DIR` specify where the MCL library is located
    - `cmake .. -DMCL_ROOT_DIR=${mcl-dir}`
- `PCSC_ROOT_DIR` specify where the PCSC library is located
    - `cmake .. -DPCSC_ROOT_DIR=${pcsc-dir}`
- `CMAKE_BUILD_TYPE` set the build type
    - valid options: `Release` or `Debug`
    
### Remote card build options
- `RKVAC_PROTOCOL_REMOTE` disable/enable the remote MULTOS card support using TCP/IP sockets (default OFF)
    - `cmake .. -DRKVAC_PROTOCOL_REMOTE=ON`
    
## Install dependencies

### Install dependencies using the package manager
```sh
apt install cmake libssl-dev libgmp-dev libpcsclite-dev pcscd
```

### Install dependencies from source

#### Compiling `zlib-1.2.11`
```sh
wget https://www.zlib.net/zlib-1.2.11.tar.gz
tar xzf zlib-1.2.11.tar.gz
cd zlib-1.2.11

./configure --prefix=/usr/local/zlib-1.2.11 --static
make -j 4
make install
```

#### Compiling `openssl-1.1.1g`
```sh
wget https://www.openssl.org/source/openssl-1.1.1g.tar.gz
tar xzf openssl-1.1.1g.tar.gz
cd openssl-1.1.1g

./Configure threads zlib \
            --with-zlib-include=/usr/local/zlib-1.2.11/include \
            --with-zlib-lib=/usr/local/zlib-1.2.11/lib \
            --prefix=/usr/local/openssl-1.1.1g \
            --openssldir=/usr/local/openssl-1.1.1g/etc \
            linux-generic32
make -j 4
make install
```

#### Compiling `gmp-6.2.0`
```sh
apt install m4
```

```sh
wget https://gmplib.org/download/gmp/gmp-6.2.0.tar.bz2
tar xjf gmp-6.2.0.tar.bz2
cd gmp-6.2.0

./configure --prefix=/usr/local/gmp-6.2.0 --enable-cxx
make -j 4
make install
```

#### Compiling `cmake-3.17.3`
```sh
apt install libcurl4-openssl-dev libbz2-dev
```

```sh
wget https://github.com/Kitware/CMake/releases/download/v3.17.3/cmake-3.17.3.tar.gz
tar xzf cmake-3.17.3.tar.gz
mkdir cmake-3.17.3/build
cd cmake-3.17.3/build

../configure --prefix=/usr/local/cmake-3.17.3 --system-curl --parallel=4 -- \
              -DOPENSSL_ROOT_DIR=/usr/local/openssl-1.1.1g \
              -DZLIB_ROOT=/usr/local/zlib-1.2.11
make -j 4
make install
```

#### Compiling `mcl-1.11`
```sh
git clone https://github.com/herumi/mcl.git
mkdir mcl/build
cd mcl/build

# v1.11
git checkout 0928a1764765609a74bd16bcd6c09467f3d959db

cmake -DCMAKE_INSTALL_PREFIX=/usr/local/mcl-1.11 -DCMAKE_BUILD_TYPE=Release -DUSE_GMP=ON -DUSE_OPENSSL=ON \
      -DCMAKE_CXX_FLAGS='-I/usr/local/gmp-6.2.0/include -I/usr/local/openssl-1.1.1g/include' \
      -DCMAKE_SHARED_LINKER_FLAGS='-L/usr/local/gmp-6.2.0/lib -L/usr/local/openssl-1.1.1g/lib' \
      -DCMAKE_EXE_LINKER_FLAGS='-L/usr/local/gmp-6.2.0/lib -L/usr/local/openssl-1.1.1g/lib' ..
make -j 4
make install
```

#### *Note for Linux and Raspberry Pi OS users:*
You must create a file with the following content:

```sh
$ nano /etc/ld.so.conf.d/10-custom-libraries.conf
```

```sh
# openssl-1.1.1g
/usr/local/openssl-1.1.1g/lib

# gmp-6.2.0
/usr/local/gmp-6.2.0/lib

# mcl-1.11
/usr/local/mcl-1.11/lib
```

```sh
$ ldconfig
```

You must also patch the PCSC library using the following commands:

```sh
sed -i 's/#include <wintypes.h>/#include \"wintypes.h\"/g' /usr/include/PCSC/pcsclite.h
sed -i 's/#include <pcsclite.h>/#include \"pcsclite.h\"/g' /usr/include/PCSC/winscard.h
sed -i 's/#ifdef __APPLE__/#if !defined(WIN32)/g' /usr/include/PCSC/wintypes.h
```

## Project structure

### Source tree

```sh
rkvac-protocol/
├── cmake
│   └── Modules
│       ├── FindMCL.cmake
│       └── FindPCSC.cmake
├── CMakeLists.txt
├── crypto
│   ├── config
│   │   └── config.h
│   ├── helpers
│   │   ├── file_helper.c
│   │   ├── file_helper.h
│   │   ├── hash_helper.c
│   │   ├── hash_helper.h
│   │   ├── hex_helper.c
│   │   ├── hex_helper.h
│   │   ├── mcl_helper.c
│   │   └── mcl_helper.h
│   ├── include
│   │   ├── attributes.h
│   │   ├── models
│   |   │   ├── issuer.h
│   |   │   ├── revocation-authority.h
│   |   │   ├── user.h
│   |   │   └── verifier.h
│   │   ├── system.h
│   │   └── types.h
│   └── src
│       ├── controllers
│       │   ├── issuer.c
│       │   ├── issuer.h
│       │   ├── multos
│       │   ├── revocation-authority.c
│       │   ├── revocation-authority.h
│       │   ├── verifier.c
│       │   └── verifier.h
│       ├── setup.c
│       └── setup.h
├── service
│   ├── config
│   │   └── service-config.h
│   ├── include
│   │   ├── multos
│   |   │   └── apdu.h
│   │   ├── attributes.h
│   │   └── help.h
│   ├── lib
│   │   ├── apdu
│   │   │   ├── command.c
│   │   │   └── command.h
│   │   ├── helpers
│   │   │   ├── mem_helper.c
│   │   │   ├── mem_helper.h
│   │   │   ├── multos_helper.c
│   │   │   └── multos_helper.h
│   │   └── pcsc
│   │   │   ├── reader.c
│   │   │   └── reader.h
│   └── src
│           └── controllers
│               └── multos
│                   ├── user.c
│                   └── user.h
├── LICENSE.md
├── main.c
└── README.md    
```

### Source description crypto part

| Directory                   | File                           | Description                                                                                                             |
| --------------------------- | ------------------------------ | ----------------------------------------------------------------------------------------------------------------------- |
|  `crypto/config/`           |  `config.h`                    | constants (maximum number of user attributes, k and j values of the revocation authority, length of the user id, etc)   |
|  `crypto/include/models/`   |  `*`                           | definition of the data structures (information) used by the issuer, the revocation authority, the user and the verifier |
|  `crypto/include/`          |  `system.h`                    | the system parameters used in elliptic curve operations (curve type, G1 and G2)                                         |
|  `crypto/include/`          |  `types.h`                     | custom defined data types used on other platforms (e.g. MULTOS)                                                         |
|  `crypto/helpers/`          |  `file_helper.{c,h}`           | function used to string and file operations                                                                             |
|  `crypto/helpers/`          |  `hash_helper.{c,h}`           | function used by the verifier to compute the hash depending on the platform where the user is running (e.g. PC, MULTOS) |
|  `crypto/helpers/`          |  `hex_helper.{c,h}`            | routines to convert the memory content into a hexadecimal string and vice versa                                         |
|  `crypto/helpers/`          |  `mcl_helper.{c,h}`            | conversion of MCL library data types to types from other platforms (e.g. MULTOS)                                        |
|  `crypto/src/controllers/`  |  `issuer.{c,h}`                | code related to the operations performed by the issuer (signature of the user attributes)                               |
|  `crypto/rc/controllers/`   |  `revocation-authority.{c,h}`  | code related to the operations performed by the revocation authority (signature and revocation attribute)               |
|  `crypto/src/controllers/`  |  `verifier.{c,h}`              | code related to the operations performed by the verifier (nonce and epoch generation, proof of knowledge verification)  |
|  `src/`                     |  `setup.{c,h}`                 | used to initialize the system parameters and the elliptic curve                                                         |

### Source description service part

| Directory                         | File                           | Description                                                                                                             |
| ----------------------------------| ------------------------------ | ----------------------------------------------------------------------------------------------------------------------- |
|  `service/config/`                |  `service-config.h`            | constants (number of credentials types, entity default directory names, default filenames, terminal colours)            |
|  `service/include/`               |  `attributes.h`                | the user attributes are defined in this file                                                                            |
|  `service/include/multos/`        |  `apdu.h`                      | header with APDU codes used for communication with the smart card                                                       |
|  `service/include/`               |  `help.h`                      | constant (help for application)                                                                                         |
|  `service/lib/apdu/`              |  `command.{c,h}`               | functions defined to build and parse APDU packets                                                                       |
|  `service/lib/helpers/`           |  `mem_helper.{c,h}`            | function used to directory and file operations                                                                          |
|  `service/lib/helpers/`           |  `multos_helper.{c,h}`         | conversion of MULTOS data types to MCL library data types                                                               |
|  `service/lib/pcsc/`              |  `reader.{c,h}`                | functions defined for sending and receiving APDU packets, smart card communication                                      |
|  `service/src/controllers/multos/`|  `user.{c,h}`                  | code related to the operations performed by the user, MULTOS (proof of knowledge computation, information storage)      |
|  `-`                              |  `main.c`                      | main routine                                                                                                            |
|  `-`                              |  `CMakeLists.txt`              | used for compiling code and building the application                                                                    |

## License
This project is licensed under the GPLv3 License - see the [LICENSE.md](LICENSE.md) file for details.

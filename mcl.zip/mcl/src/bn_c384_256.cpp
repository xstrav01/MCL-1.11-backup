/*
	implementation of mclBn_* apis
*/
#define MCLBN_FP_UNIT_SIZE 6
#define MCLBN_FR_UNIT_SIZE 4
#include "mcl/impl/bn_c_impl.hpp"


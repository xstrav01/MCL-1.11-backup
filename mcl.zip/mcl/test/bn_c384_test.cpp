#include <mcl/bn384.hpp>
using namespace mcl::bn384;
#define MCLBN_DEFINE_STRUCT
#define MCLBN_FP_UNIT_SIZE 6
#include "bn_c_test.hpp"


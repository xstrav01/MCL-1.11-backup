package cz.feec.vutbr.WebApp;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Read_file {
    public static ArrayList read(String path) throws IOException {
        ArrayList arr = new ArrayList();

        File file = new File(path);
        BufferedReader br = new BufferedReader(new FileReader(file));
        try {
            String st;
            while ((st = br.readLine()) != null)
                arr.add(st);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            br.close();
        }

        return arr;
    }


}

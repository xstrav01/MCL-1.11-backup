package cz.feec.vutbr.WebApp;

import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLOutput;
import java.util.Date;

public class RevocationListener extends Thread {

    private ServerSocket ss;
    private String epoch;

    public RevocationListener(int port) {
        try {
            ss = new ServerSocket(port);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void run() {
        while (true) {
            try {
                Socket clientSock = ss.accept();
                InetAddress ra = InetAddress.getByName(StudentController.raAddress);
                InetAddress client = clientSock.getInetAddress();
                if(ra.equals(client)) {
                    System.out.println("\n"+new Date()+" Client accepted from: " +clientSock.getInetAddress().toString());
                    saveFile(clientSock);
                    updateBlacklist();
                }
                else {
                    System.out.println("\n"+new Date()+" Client accepted from: " +clientSock.getInetAddress().toString());
                    System.out.println("\n"+new Date()+" "+clientSock.getInetAddress().toString()+ " doesn´t match RA IP Address, quitting...");
                    clientSock.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                System.out.println("Cannot update blacklist.");
                e.printStackTrace();
            }
        }
    }

    private void updateBlacklist() throws IOException, InterruptedException {
        System.out.println(new Date()+" Updating blacklist.");
        RKVAC_handler rkvac = new RKVAC_handler();
        rkvac.addAttributes("-v");
        rkvac.addAttributes("-u");
        String epochPath= "/home/rkvac/rkvac_web/rkvac-protocol/build/data/Verifier/ra_BL_epoch_"+epoch+"_C_for_verifier.dat";
        rkvac.addAttributes(epochPath);
        rkvac.start();

    }

    private void saveFile(Socket clientSock) throws IOException {
        String epoch = new String(Files.readAllBytes(Path.of("/home/rkvac/rkvac_web/rkvac-protocol/build/data/Verifier/ve_epoch.dat")));
        this.epoch = epoch;
        DataInputStream dis = new DataInputStream(clientSock.getInputStream());
        FileOutputStream fos = new FileOutputStream("/home/rkvac/rkvac_web/rkvac-protocol/build/data/Verifier/ra_BL_epoch_"+epoch+"_C_for_verifier.dat");
        byte[] buffer = new byte[4096];

        int count = 0;
        while ((count = dis.read(buffer)) > -1)
        {
            fos.write(buffer, 0, count);
        }

        fos.close();
        dis.close();

        clientSock.close();
        System.out.println(new Date()+ " Client socket closed");
    }

}

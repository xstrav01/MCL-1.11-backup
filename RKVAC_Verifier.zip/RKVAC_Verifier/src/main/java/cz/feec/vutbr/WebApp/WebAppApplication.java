package cz.feec.vutbr.WebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Date;

@SpringBootApplication
public class WebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebAppApplication.class, args);

		System.out.println(new Date() + " Starting revocation listener on port 5003");
		RevocationListener revocationServer = new RevocationListener(5003);
		revocationServer.start();

		try {
			WebController.verificationLoop();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}


}

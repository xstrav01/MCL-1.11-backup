package cz.feec.vutbr.WebApp;

import java.io.Serializable;

public class Settings implements Serializable {

    protected Boolean inCycles = true;
    protected String RAaddress = "None";
    protected String cron = "0 10 0 * * 1";

    public String getCron() {
        return cron;
    }
    public void setCron(String cron) {
        this.cron = cron;
    }
    public Boolean getInCycles() {
        return inCycles;
    }

    public void setInCycles(Boolean inCycles) {
        this.inCycles = inCycles;
    }

    public String getRAaddress() {
        return RAaddress;
    }

    public void setRAaddress(String RAaddress) {
        this.RAaddress = RAaddress;
    }

}

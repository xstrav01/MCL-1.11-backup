package cz.feec.vutbr.WebApp;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.Map;

@RestController
public class Api {

    @RequestMapping(value = "/Verifier/api", produces = MediaType.APPLICATION_JSON_VALUE)
    public Map getState() {
        //return Collections.singletonMap("state",String.valueOf(WebController.states.AccessDenied));
        return Collections.singletonMap("state", WebController.state.toString());

    }
}

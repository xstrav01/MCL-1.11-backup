package cz.feec.vutbr.WebApp;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Entity
public class Student implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @NotBlank(message = "Name is mandatory")
    @Column(name = "name")
    private String name;

    @Column
    protected String status = "-";

    @Column
    protected int attributeCount = 1;

    @Column
    protected String activePositions = "";

    @Column
    private String att1 = "";

    @Column
    private String att2 = "";

    @Column
    private String att3 = "";

    @Column
    private String att4 = "";

    @Column
    private String att5  = "";

    @Column
    private String att6 = "";

    @Column
    private String att7 = "";

    @Column
    private String att8 = "";

    @Column
    private String att9 = "";


    public Student(String name) {
        this.name = name;
    }
    public Student() {
    }


    public String getElements(){


        switch (this.getAttributeCount()) {
            case 1:
                return "[1]: " +  att1;

            case 2:
                return "[2]: " + att1 + ", " + att2;

            case 3:
                return "[3]: " + att1 + ", " + att2 + ", " + att3;

            case 4:
                return "[4]: " +  att1 + ", " + att2 + ", " + att3 + ", " + att4;

            case 5:
                return "[5]: " +  att1 + ", " + att2 + ", " + att3 + ", " + att4 + ", " + att5;

            case 6:
                return "[6]: " +  att1 + ", " + att2 + ", " + att3 + ", " + att4 + ", " + att5 + ", " + att6;

            case 7:
                return "[7]: " +  att1 + ", " + att2 + ", " + att3 + ", " + att4 + ", " + att5 + ", " + att6 + ", " + att7;

            case 8:
                return "[8]: " +  att1 + ", " + att2 + ", " + att3 + ", " + att4 + ", " + att5 + ", " + att6 + ", " + att7 + ", " + att8;

            case 9:
                return "[9]: " +  att1 +", " + att2 + ", " + att3 + ", " + att4 + ", " + att5 + ", " + att6 + ", " + att7 + ", " + att8 + ", " + att9;

        }
        return "";
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public String getAtt1() {
        return att1;
    }

    public void setAtt1(String att1) {
        this.att1 = att1;
    }

    public String getAtt2() {
        return att2;
    }

    public void setAtt2(String att2) {
        this.att2 = att2;
    }

    public String getAtt3() {
        return att3;
    }

    public void setAtt3(String att3) {
        this.att3 = att3;
    }

    public String getAtt4() {
        return att4;
    }

    public void setAtt4(String att4) {
        this.att4 = att4;
    }

    public String getAtt5() {
        return att5;
    }

    public void setAtt5(String att5) {
        this.att5 = att5;
    }

    public String getAtt6() {
        return att6;
    }

    public void setAtt6(String att6) {
        this.att6 = att6;
    }

    public String getAtt7() {
        return att7;
    }

    public void setAtt7(String att7) {
        this.att7 = att7;
    }

    public String getAtt8() {
        return att8;
    }

    public void setAtt8(String att8) {
        this.att8 = att8;
    }

    public String getAtt9() {
        return att9;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setAtt9(String att9) {
        this.att9 = att9;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAttributeCount() {
        return attributeCount;
    }

    public void setAttributeCount(int attributeCount) {
        this.attributeCount = attributeCount;
    }
    public String getActivePositions() {
        return activePositions;
    }

    public void setActivePositions(String activePositions) {
        this.activePositions = activePositions;
    }
}

  {
    /* Changing attributes */

const attributeCount = document.getElementById('attributeCount');
attributeCount.addEventListener('change', setInputs);
function setInputs() {
        let selectedValue = attributeCount.value;
        for (var i = 9; i > selectedValue; i--) {
            var element = document.getElementById((i));
            element.style.display = 'none';
            var input = document.getElementById(("att"+i))
            input.value = "";

        }
        for (var i = 1; i <= selectedValue; i++) {
            var element = document.getElementById((i));
            element.style.display = '';
            }
    }
window.onload = setInputs;




}